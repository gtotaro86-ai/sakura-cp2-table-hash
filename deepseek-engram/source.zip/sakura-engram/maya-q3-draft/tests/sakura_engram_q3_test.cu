// Test both REAL Maya Engram GPU entry points against ggml-generated fixtures.
// No model, network, tokens or paid resources. Requires an existing CUDA/HIP GPU.
#include "../src/ds4/ds4_kernels.cuh"
#include <cuda_runtime.h>
#include <algorithm>
#include <cstring>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <vector>
using namespace strata::ds4;
static void check(cudaError_t status) { if(status!=cudaSuccess)throw std::runtime_error(cudaGetErrorString(status)); }
static std::vector<uint8_t> load(const char* path) {
    std::ifstream f(path,std::ios::binary|std::ios::ate);if(!f)throw std::runtime_error("fixture missing");
    const auto n=f.tellg();if(n<=0 || n>1024*1024)throw std::runtime_error("fixture size");
    std::vector<uint8_t> bytes((size_t)n);f.seekg(0);f.read((char*)bytes.data(),n);
    if(!f)throw std::runtime_error("fixture short read");return bytes;
}
int main(int argc,char** argv) {
    try {
        if(argc!=3)throw std::runtime_error("usage: sakura_engram_q3_test codes.q3 expected.f32");
        const auto packed=load(argv[1]),expected=load(argv[2]);
        if(packed.size()%110 || expected.size()!=packed.size()/110*256*4)throw std::runtime_error("bad fixtures");
        const int n=(int)(packed.size()/110),hd=256,cols=4;
        if(n%cols)throw std::runtime_error("fixture row count divisible by four required");
        const size_t per=cols*(hd+hd/32);
        for(bool token_layout:{false,true}) {
            std::vector<uint8_t> padded(token_layout ? (n/cols)*per : n*(hd+hd/32),0xa5);
            for(int r=0;r<n;++r) {
                const size_t off=token_layout ? (r/cols)*per+(r%cols)*hd : r*hd;
                std::memcpy(padded.data()+off,packed.data()+r*110,110);
            }
            uint8_t* device=nullptr;float* out=nullptr;
            check(cudaMalloc((void**)&device,padded.size()));check(cudaMalloc((void**)&out,expected.size()));
            check(cudaMemcpy(device,padded.data(),padded.size(),cudaMemcpyHostToDevice));
            if(token_layout)engram_dequant_tok(device,per,cols,n/cols,hd,out,nullptr,kEngramQ3K);
            else engram_dequant(device,device+n*hd,n,hd,out,nullptr,kEngramQ3K);
            check(cudaGetLastError());check(cudaDeviceSynchronize());
            std::vector<uint8_t> got(expected.size());check(cudaMemcpy(got.data(),out,got.size(),cudaMemcpyDeviceToHost));
            check(cudaFree(out));check(cudaFree(device));
            if(got!=expected)throw std::runtime_error(token_layout ? "token/chunk GPU mismatch" : "decode GPU mismatch");
        }
        std::cout<<"PASS both Maya Q3_K GPU paths bit-exact against supplied ggml fixture\n";
        return 0;
    }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
