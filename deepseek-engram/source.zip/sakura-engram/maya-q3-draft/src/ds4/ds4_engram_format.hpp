// Explicit on-disk Engram formats and checked payload geometry.
#pragma once
#include <cstdint>
#include <limits>
namespace strata::ds4 {
constexpr int kEngramFp8 = 0, kEngramQ6K = 1, kEngramQ3K = 2;
inline bool engram_qk_layout_valid(int format, int hd, uint64_t rows, uint64_t bytes) {
    if ((format!=kEngramQ3K && format!=kEngramQ6K) || hd<=0 || hd%256!=0 || rows==0) return false;
    const uint64_t stride=uint64_t(hd/256)*(format==kEngramQ3K ? 110u : 210u);
    return rows<=std::numeric_limits<uint64_t>::max()/stride && rows*stride==bytes;
}
inline bool engram_range_valid(uint64_t offset,uint64_t bytes,uint64_t file_bytes) {
    return offset<=file_bytes && bytes<=file_bytes-offset;
}
} // namespace strata::ds4
