# DeepSeek-V4.1-Flash-1017: kostenlose Online-Tabellenquantisierung

Geprüft am 2026-10-22. Kein neuer HF-Repo, kein Modell veröffentlicht, kein kostenpflichtiger Job, kein GitHub-Lauf gestartet. Lokal wurden nur kleine Quellen/Metadaten sowie **20.544 Bytes** aus den Engram-GGUFs gelesen (zwei 192-Byte-Header und 96 echte Q6_K-Zeilen). Keine vollständigen Tabellen oder Modelle heruntergeladen.

## Ergebnis

**Transport und Streaming sind möglich; ein fertiger DeepSeek-CP2-Build wie Flash-Next ist derzeit nicht vorhanden.** Die Trennung der Tabellen ist günstig. Erstmalige Kodierung, Formatunterstützung und Qualitätsprüfung sind zusätzliche Arbeit. Q3_K auf CPU ist nach dem kleinen realen Zeilentest der aussichtsreichere kostenlose Pilot; CP-256 mit dem vorhandenen NumPy-Encoder ist für den Vollumfang nicht praktikabel.

## Tatsächlich geprüfte Quellen

- Maya-GGUF: [peasantsmith/DeepSeek-V4.1-Flash-1017-Maya-GGUF](https://huggingface.co/peasantsmith/DeepSeek-V4.1-Flash-1017-Maya-GGUF), Revision `b9e25f34b53806b24e5b18085de6ed5967ad9ed5`.
- Unsloth-Inventar: `unsloth/DeepSeek-V4.1-Flash-1017-GGUF`, Revision `60ad3651641b5c97679c807e064ab1d7a3ca1455`. Eine fertige CP-256-Tabelle ist darin nicht ausgewiesen.
- DeepSeek-Konfiguration: `deepseek-ai/DeepSeek-V4.1-Flash-1017`, Revision `1bae0e1088993b9b82de08f59de5be5f34e42170`. Engram-Layer 1/14, 256 Werte pro Zeile, 384.006.168 und 384.016.682 Zeilen.
- [Project Maya](https://github.com/mw00/project-maya), Revision `451f9cb6a21ea65673bdde2e57b4a670ae2b8859`. Gelesen: Packer, GGUF-/Engram-Reader, Engine und Buildkonfiguration.
- Vorhandener lokaler CP-256-Prototyp unter `D:\AI\Quantisierung\modelle\DeepSeek41-Skeleton-CP2-Test`. Alte Skeleton-Tests sind synthetisch; hier wurden zusätzlich acht echte Q6_K-Zeilen kodiert.
- [GitHub-Runner](https://docs.github.com/en/actions/reference/runners/github-hosted-runners) und [Actions-Limits](https://docs.github.com/en/actions/reference/limits): öffentlicher Standard-Linux-Runner 4 vCPU / 16 GB RAM / 14 GB SSD, CPU; höchstens sechs Stunden je regulärem Job. Größere/GPU-Runner sind nicht der hier angenommene kostenlose Weg.

## Split und Hashbelege

Die aktuellen LFS-SHA256 und Größen aller sechs Maya-S-Dateien stimmen mit den bereits gelesenen GGUF-Verzeichnissen überein. Die beiden Tabellenheader wurden zusätzlich frisch gelesen und bytegenau verglichen. Sie sind jeweils 192 Bytes lang.

| Dateien | Inhalt | Umfang |
|---|---|---:|
| Maya-S Shards 1–4 | Modellrumpf ohne große Engram-Tabellen | 178.193.155.104 Bytes |
| Shard 5 | ausschließlich `blk.1.engram_embd.weight`, [256, 384006168], Typ 14/Q6_K | 80.641.295.280 Bytes Payload |
| Shard 6 | ausschließlich `blk.14.engram_embd.weight`, [256, 384016682], Typ 14/Q6_K | 80.643.503.220 Bytes Payload |

Zusammen **768.022.850 Zeilen / 196.613.849.600 Werte / 161.284.798.500 Bytes Q6_K-Payload**. Jede Q6_K-Zeile besteht aus einem 256er-Block mit 210 Bytes.

Die ersten vier Dateien könnten mit dem bereits erfolgreich verwendeten HF-`CommitOperationCopy` übernommen werden. Der Eingangsinhalt muss dafür nicht über den Nutzer-PC fließen. Für dieses DeepSeek-Modell wurde noch keine neue Kopierveröffentlichung vorgenommen. Aktuell liegen auch zwei Maya-XS-Tabellen-Shards im Quellrepo; die übrigen erforderlichen XS-Shards fehlen im geprüften Inventar. Das ist noch kein vollständiges zusätzliches Modell.

## Kleine echte Messung

Vorhandene geprüfte ggml-base.dll, SHA256 `5668eed04ef499ece9372075d4444b94dcc21e5f8e119cc5d7a1f645ca0c8158`. 96 echte Zeilen aus Anfang/Mitte/Ende beider Tabellen dequantisiert. Q2_K/Q3_K auf einem kleinen wiederholten RAM-Array gemessen; CP-256 auf acht echten, verteilt ausgewählten Zeilen. Es wurde kein vollständiges Modell geladen.

| Format | Tabellenpayload, rechnerisch | Gesamtes Hauptmodell, ungefähr | Befund |
|---|---:|---:|---|
| Q6_K, vorhanden | 161,285 GB | 339,478 GB | unveränderte Ausgangslage |
| Q3_K | 84,483 GB | 262,676 GB | CPU-Quantisierung auf echter Probe funktioniert |
| Q2_K | 64,514 GB | 242,707 GB | CPU-Quantisierung funktioniert, langsamere lokale Quantizer-Implementierung |
| experimentelles CP-256 | 50,690 GB | 228,883 GB | Prototyp kodiert echte Zeilen, Vollumfang mit diesem Encoder unpraktikabel |

GB = 10^9 Bytes. Neue Größen sind aus Zeilenzahl und Formatblockgrößen berechnet; neue vollständige Dateien wurden nicht erzeugt. Bei CP-256 kämen noch wenige Format-/Codebook-Metadaten hinzu. Nicht als RAM-/VRAM-Anforderung verwenden.

- Lokale warme CPU-Mikromessung: Q3_K etwa 711.356 Zeilen/s, Q2_K etwa 98.443 Zeilen/s. Nur Rechenkern, kleines wiederholtes Array; keine GitHub-Messung und keine Ende-zu-Ende-Laufzeitprognose.
- CP-256: acht echte Zeilen in **2,289 s**, etwa **3,50 Zeilen/s**. Eine rein lineare serielle Hochrechnung derselben Implementierung auf dieselbe Maschine ergibt knapp sieben Jahre. Das ist keine untere Grenze für einen optimierten nativen oder GPU-Encoder, belegt aber die Untauglichkeit dieses unveränderten Prototyps für einen Vollauftrag.
- Ein kompletter einfacher Durchlauf in sechs Stunden benötigt allein mindestens **35.557 Zeilen/s**, vor Uploads, weiteren Hashdurchläufen und sonstigem Aufwand.
- Zeilen-RRMSE gegenüber dem vorhandenen Q6_K-Input: Q3_K ca. 15,24 %, Q2_K ca. 29,66 %, CP-256 ca. 27,18 % auf jeweils kleinen Proben. Diese Fehlermaße sind **keine** PPL-/Antwortqualitäts- oder Aufgabenbewertung.

Reproduzierbare Details: `pilot-results.json`, `table-audit.json`, kleine Sample-Dateien und der lokale Messcode im Workspace. Der eingefrorene 512×2-Gaussian-Codebook-Rohhash ist `ac32c9a1dfb6f7e144ab1addc522da1b54abc69e53a8198064f9305798f864b3`.

## Konkreter Runtime-Blocker

In Mayas `src/ds4/ds4_model.cu` um Zeile 2723 wird pro Engram-Layer nur ein Q6_K-Schalter gesetzt. Der Zeilenleser um 5222 behandelt MXFP8, Q6_K und die entsprechende FP8/Scale-Anordnung. Die späteren GPU-Aufrufe erhalten wieder nur den Q6_K-Schalter. Eine generische Q3_K- oder CP-256-Engram-Auswahl gibt es dort nicht.

Der Packer kennt zwar allgemeine GGML-Typnummern Q2_K/Q3_K; das beweist keine Unterstützung dieses speziellen Engram-Laufpfads. Für CP-256 fehlt zusätzlich die Typregistrierung im Packer. **Q3_K oder CP-256 darf nicht als Q6_K etikettiert werden.** Ebenso darf das 160er-Qwen-CP2-Format nicht einfach als DeepSeek-256er-Tabelle benutzt werden.

Der lokale CP-256-Port betrifft einen isolierten llama.cpp-CPU-Testtyp 240. Er ist kein portierter Maya-Decoder und keine qualifizierte Windows/AMD-GPU-Runtime. Maya bietet CUDA und HIP in seiner Buildkonfiguration, aber hier wurde kein DeepSeek-Q3-/CP-256-Betrieb auf dem konkreten Ryzen-AI-Max+-392-System nachgewiesen.

## Kostenloser Weg ohne vollständigen PC-Download

1. Begrenzter CPU-Runner-Pilot mit realen HTTP-Ranges: Quantisierungsgeschwindigkeit, Netzwerk und deterministische Ausgaben messen. Das lokale Paket `github-pilot/` ist dafür vorbereitet: öffentlicher Standard-`ubuntu-24.04`, maximal 45 Minuten, kein HF-Token, keine Modelluploads, keine großen Artefakte. Default etwa 20,6 MB Modellproben ausschließlich auf dem Runner. Lokal verweigert das Skript Netzwerk-Modelldaten.
2. Maya-Engram-Reader und Decoder für das gewählte Format ergänzen und mit echten Zeilen gegen die Referenz testen; danach echte Modell-/Qualitätsprüfung. Q3_K ist der kurzfristig deutlich realistischere CPU-Weg. CP-256 braucht zunächst einen erheblich schnelleren, korrekt getesteten Encoder.
3. Für einen Vollbau je eine Tabelle pro Job als deterministischen seekbaren Quantisierungsstrom erzeugen und direkt nach HF hochladen. Analog zum Flash-Next-Transport wird die komplette 42,24-GB-Q3-Datei nicht auf der 14-GB-Runner-Disk materialisiert. Kleine begrenzte Blöcke liegen in RAM. Das dafür nötige vollständige neue virtuelle Quantisierungsdatei-Objekt ist noch nicht implementiert oder qualifiziert.
4. Hash-/Uploaddurchläufe einkalkulieren: ein virtuelles HF-Dateiobjekt wird vor dem Upload vollständig gehasht und später erneut gelesen. Das kann die Q6_K-Quelldaten und die CPU-Quantisierung mindestens zweimal benötigen. Ein Job-Laufzeitnachweis fehlt noch. Eine deterministisch identische zweite Kodierung muss vor einem Upload geprüft sein.
5. Erst mit kompatibler Runtime, benanntem Teststand, geprüften Hashes und erlaubtem HF-Speicher eine Veröffentlichung freigeben. Andere Backbones können nur nach nachgewiesener Tabellen-/Adressierungskompatibilität dieselbe komprimierte Tabelle erhalten.

HF-Speicher ist ein eigener Prüfpunkt: [Free public storage ist Best-effort](https://huggingface.co/docs/hub/storage-limits), keine unbegrenzte garantierte Quote. Neue Tabellen verursachen etwa 50,7–84,5 GB zusätzlichen logischen Dateiinhalt; für Kopien darf keine automatische quota-neutrale Xet-Deduplikation angenommen werden. Der verfügbare Account-Rest wurde hier nicht als ausreichend bestätigt. Ein rein lesender Pilot benötigt keinen neuen HF-Speicher.

## Was fertig ist / was offen bleibt

Fertig: aktuelle Inventare, Quellcodeprüfung, aktuelle Header-/Hashzuordnung, echter kleiner CPU-Quantisierungsversuch, Größenrechnung und lokal vorbereitetes begrenztes GitHub-Pilotpaket (Python syntaktisch geprüft, YAML geparst, lokale Ausführungssperre getestet).

Offen: GitHub-Runner-Ausführung des neuen Piloten, Format-/Maya-Decoderport, echte Qualitätsmessung, voller Streaming-Quantisierungsuploader und Speicher-/6-Stunden-Nachweis. Es wurde kein neues öffentliches Workflow-Repository angelegt oder ein fremdes GitHub-Repo verändert.

