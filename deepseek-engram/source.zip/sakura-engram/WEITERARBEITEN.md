# Sakura DeepSeek Engram – Cloud-Fortsetzung

Aktueller verbindlicher Einstieg: **RELEASE_STATUS.md**, danach **release/CLOUD_START.md** und **release/README.md**. Stand 22.10.2026.

Das Paket enthält den bisherigen Cloud-Arbeitsstand vollständig, einschließlich Originalübergabe, begrenztem Pilot, geprüften CPU-Bausteinen, CUDA-Kompilierungsnachweisen und Release-Vorbereitung. Ältere JSON-Befunde sind historische Messungen des dort benannten Testlaufs; der aktuelle CUDA-/CPU-Status steht unter release/.

## Auftragsgrenzen bleiben bestehen

- Keine kostenpflichtigen Jobs, Runner, GPUs oder API-Ausgaben.
- Keine vollständigen Modelle/Tabellen auf den Windows-PC herunterladen.
- Veröffentlichung ohne vollständigen Inferenztest ist jetzt freigegeben; vorgeschriebener öffentlicher Hinweis steht in release/release-policy.json. Bisher keine Modellgewichte veröffentlicht.
- Nur die beiden Engram-Tabellen quantisieren. Vier Backbone-Dateien unverändert übernehmen, erst nach Transport-/Quota-/Regionsprüfung.
- Keine neuen Token/Credentials erfinden; kein Zugriff auf frühere C:/D:-Pfade.
- 100.000.000 Bytes Gesamtbudget für öffentliche gepinnte Modell-Ranges, bisher 20.658.048 Bytes. cloud-pilot/budget.json erhalten und nicht zum Umgehen des Limits löschen. HTTP 200 vor dem Lesen verwerfen.
- Neun Flash-Next-Repos nicht erneut bauen/umbenennen; Mapping in flash-next-rename-mapping.json. Unsloth bleibt direkte Quelle im Model Tree.
- https://github.com/gtotaro86-ai/sakura-cp2-table-hash enthält alte IDs und wurde nicht geändert oder gestartet.

## Nächste Arbeit

Die aktuell möglichen Offline-/CPU-Prüfungen und CUDA-Übersetzungen sind erledigt. Der Nutzer hat den Release ohne vollständigen Inferenztest freigegeben. Offen bleiben tatsächlicher Cloud-Bau, Upload, Speicher und Datei-/Hashprüfungen; keine GPU-/Qualitätsprüfung als bestanden darstellen. release/QUALITY_PLAN.md und der verlinkte GPU-Test legen die nächsten Abnahmeschritte konkret fest. release/check_release_gate.py muss bis dahin Exitcode 2 liefern.

Für den bereits freigegebenen Release Transport-/Dateinachweise aktualisieren und den kurzen Hinweis erhalten. Keine gegenwärtig laufende Hintergrundaufgabe behaupten: Die Rechenprüfungen wurden abgeschlossen; Fortsetzung über eine neue Nachricht im selben Chat. Der Nutzer-PC kann ausgeschaltet bleiben. Nach Verlust des flüchtigen Workspaces dieses Archiv wiederherstellen; Buildbinaries, SDKs und große Git-Checkouts sind reproduzierbar und nicht Bestandteil des kleinen Pakets.

## Reproduktion

Die Offline-Suite braucht eine CPU-Bibliothek aus der gepinnten llama.cpp-Revision (ggml-reference.json), Python 3.12/NumPy und g++. Dann: python release/run_cpu_checks.py. Ohne neue Modellrequests werden Decoder-, Reader-/Cache-, Range-/Budget-, Format- und Streamingtests durchgeführt.

Der neue CUDA-Compilerlauf ist mit release/compile_cuda_checks.py reproduzierbar, benötigt einen gepatchten Maya-Checkout und den in release/cuda-toolchain-provenance.json dokumentierten SDK-Stand. Er führt kein GPU-Programm aus. release/cuda-build-status.json enthält Kommandos, Lognamen und Hashes aller Patchdateien des geprüften Checkouts.

Alle Quellen/Artefakte sind im CHECKPOINT-SHA256.json erfasst, ausgenommen dieses Manifest selbst. python release/verify_package.py prüft sie vor der Fortsetzung. Lokale Codeänderungen erfordern danach ein neu erzeugtes Manifest und aktualisierte Prüfbelege.
