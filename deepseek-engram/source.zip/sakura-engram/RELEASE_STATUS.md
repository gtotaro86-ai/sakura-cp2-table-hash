# Sakura DeepSeek Engram – Release-Vorbereitung

Stand: 22.10.2026. **Vorbereitungspaket fertig; Modell-Release noch blockiert.** Es wurde kein Modell veröffentlicht und kein kostenpflichtiger Dienst/Job gestartet.

## Fertig und praktisch nachgewiesen

| Baustein | Ergebnis |
|---|---|
| Übergabe | Vier ursprüngliche Manifest-Hashes exakt, Syntax/YAML geprüft |
| Quellinventar | Größen/LFS-SHA256 aller sechs GGUFs an gepinnter HF-Revision bestätigt |
| Begrenzter Cloud-Pilot | 98.304 echte Zeilen; Q3-Kodierung dreimal pro Probe identisch |
| Q3-CPU-Decoder | Bitgenaue ggml-Parität: 192 echte quantisierte Zeilen, 4.096 Zufallsblöcke, 63.488 endliche FP16-Skalen |
| Original-Maya-Reader/Cache | 64-Bit-Dateioffsets, Token-Slots, Cache/Duplikate, Eviction und Short-Read geprüft |
| Runtime-Patch | Echte Q3-Typauswahl, 110-Byte-Blöcke, Form-/Größen-/Datei-/Bucket-Prüfungen; Q6/FP8 bleiben getrennt |
| CUDA-Kompilierung | `ds4_kernels.cu`, `ds4_model.cu` und GPU-Test für sm_80 mit CUDA 13.0.88 erfolgreich übersetzt |
| CUDA-Testlink | Test gegen beide echten Maya-Engram-Einstiegspunkte erfolgreich verlinkt; keine GPU-Ausführung |
| Virtuelle GGUF-Datei | Bounded Reads/Seeks, korrekte Header/Streamlänge, blockunabhängige Bytes, identische Hash-Durchläufe geprüft |
| Downloadschutz | HTTP-200-/Range-/Längen-/Encoding-Prüfung vor Lesen, persistentes Budget mit Linux-Dateisperre/atomarer Reservierung |
| Release-Material | Offline-CPU-Workflow, reproduzierbare Compilerprüfung, Modellkartenentwurf, Kopierplan, Qualitätsplan, Hashmanifest und gesperrtes Release-Gate |

## Gemessener Umfang

Cloud-Modelldaten bisher insgesamt **20.658.048 Bytes**: ursprünglicher Pilot 20.644.224 Bytes plus 13.824 Bytes für zwei winzige Streaming-Fixtures inklusive Header. Gesamtlimit bleibt 100.000.000 Bytes. Compilerpakete und Quellcode sind keine Modellproben und wurden getrennt bezogen. Keine vollständige Tabelle oder Modellgewichte auf den Nutzer-PC geladen.

Q3_K: Median der sechs Probenmediane ca. **263.997 Zeilen/s**, CPU-Quantizer. Das ist keine Ende-zu-Ende-Prognose. Der unveränderte CP-256-NumPy-Encoder erreicht hier etwa 2,19 Zeilen/s und bleibt ungeeignet für den Vollbau.

Rechnerisches neues Hauptmodell: **262.675.668.988 Bytes** inklusive zwei Tabellenheadern, davon unveränderter Rumpf 178.193.155.104 Bytes. Dies ist keine UMA-/RAM-Bedarfsangabe und kein Nachweis für Betrieb auf 64 GB.

## Aktueller Auftrag: Cloud-Bau und Release ohne vollständigen Inferenztest

Die Veröffentlichung ist vom Nutzer freigegeben. Die öffentliche Modellkarte verwendet den kurzen Hinweis: **„Es wurde kein vollständiger Inferenztest durchgeführt.“** Vollständige Inferenz, GPU-Ausführung und Windows/HIP-Qualifikation sind nicht erfolgt; sie werden nicht als bestanden ausgegeben und sind auf Nutzerwunsch keine Voraussetzung für diesen Release.

Noch offen sind der wirkliche vollständige Cloud-Bau/Upload, verfügbare HF-Schreibrechte und kostenloser Zielspeicher, serverseitige Kopie und abschließende remote Dateihashes. Der neue Upload-/Release-Code ist implementiert und gegen HF 2.2.0 offline geprüft, aber noch nicht remote durchgelaufen. Weitere Details: `release/CLOUD_START.md`.

GitHub ist jetzt verbunden. Die bestehenden Dateien und alten Workflows des ursprünglichen Hash-Repositories werden nicht überschrieben oder gestartet. Der neue Cloud-Workflow ist getrennt vorbereitet. Ein HF-Schreib-Token muss geschützt als GitHub-Secret verfügbar sein.

`python release/check_release_gate.py` liefert bis zum tatsächlichen vollständigen Bau weiterhin Exitcode 2. Es läuft kein Vollbau, solange der neue Workflow nicht tatsächlich gestartet wurde.

## Einstieg

`release/README.md` enthält Reproduktion und Abnahmeschritte; `release/release-plan.json` die genaue Dateistruktur und offenen Nachweise. `release/cpu-checks.json` und `release/cuda-build-status.json` sind die neuen Prüfbelege. Ursprüngliche Messungen stehen getrennt in `pilot-results.json`; Cloud-Messungen in `cloud-pilot/results.json`. Die neun vorhandenen Flash-Next-Repos sowie das alte Hash-Workflow-Repo wurden nicht verändert.
