"""Bounded read-only CPU pilot. No HF token, model upload, or full-table read."""
import argparse,ctypes,hashlib,json,os,time,urllib.request
from pathlib import Path
import numpy as np

def main():
    if os.environ.get('GITHUB_ACTIONS')!='true':
        raise SystemExit('Remote pilot only: refusing model-row downloads on the user PC')
    if os.environ.get('REPO_VISIBILITY')!='public':
        raise SystemExit('Requires a public repository and free standard runner')
    ap=argparse.ArgumentParser();ap.add_argument('--library',required=True);ap.add_argument('--rows',type=int,default=16384);args=ap.parse_args()
    if not 16<=args.rows<=65536:raise SystemExit('Rows per range must be 16..65536')
    audit=json.loads(Path('table-audit.json').read_text());lib=ctypes.CDLL(args.library)
    lib.dequantize_row_q6_K.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_int64]
    lib.ggml_quantize_chunk.argtypes=[ctypes.c_int,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_int64,ctypes.c_int64,ctypes.c_int64,ctypes.c_void_p]
    lib.ggml_quantize_chunk.restype=ctypes.c_size_t
    runs=[];actual_bytes=0;cp_rows=[]
    for tab in audit['tables']:
        sh=tab['shard'];f=next(c['file'] for c in audit['cached_shards'] if c['shard']==sh)
        t=tab['tensor'];rows=t['shape'][1]
        for row_start in (0,rows//2,rows-args.rows):
            start=t['absolute']+row_start*210;count=args.rows*210;end=start+count-1
            url='https://huggingface.co/'+audit['repo']+'/resolve/'+audit['revision']+'/'+f['path']+f'?pilot={start}-{end}'
            req=urllib.request.Request(url,headers={'Range':f'bytes={start}-{end}','Accept-Encoding':'identity'})
            begun=time.perf_counter()
            with urllib.request.urlopen(req,timeout=90) as r:
                if r.status!=206 or r.headers.get('Content-Range')!=f"bytes {start}-{end}/{f['size']}":
                    raise RuntimeError('Exact range required; refusing a whole response')
                raw=r.read(count+1)
                if len(raw)!=count:raise RuntimeError('Range length mismatch')
            fetch=time.perf_counter()-begun;actual_bytes+=count
            src=ctypes.create_string_buffer(raw);x=np.empty((args.rows,256),np.float32)
            lib.dequantize_row_q6_K(src,x.ctypes.data,x.size)
            if not np.isfinite(x).all():raise RuntimeError('Nonfinite source')
            cp_rows.append(x[0].copy());measurements=[]
            for typ,name,bpr in ((10,'Q2_K',84),(11,'Q3_K',110)):
                out=np.empty((args.rows,bpr),np.uint8);times=[];digests=[]
                for _ in range(3):
                    tick=time.perf_counter()
                    n=lib.ggml_quantize_chunk(typ,x.ctypes.data,out.ctypes.data,0,len(x),256,None)
                    times.append(time.perf_counter()-tick)
                    if n!=out.size:raise RuntimeError('Output size mismatch')
                    digests.append(hashlib.sha256(out.tobytes()).hexdigest())
                if len(set(digests))!=1:raise RuntimeError('Repeated encoding not deterministic')
                measurements.append({'type':name,'rows_per_second':len(x)/min(times),'sha256':digests[0]})
            runs.append({'shard':sh,'row_start':row_start,'rows':args.rows,'bytes':count,'fetch_seconds':fetch,'source_sample_sha256':hashlib.sha256(raw).hexdigest(),'quantizers':measurements})
    import cp256_codec
    book=np.load('codebook-v1.npy');xx=np.array(cp_rows,dtype=np.float32)
    tick=time.perf_counter();codes=cp256_codec.encode_cpu(xx,book);cp_seconds=time.perf_counter()-tick
    recon=cp256_codec.decode_records(codes,book)
    if not np.isfinite(recon).all():raise RuntimeError('Bad CP256 decode')
    result={'source_revision':audit['revision'],'range_bytes':actual_bytes,'full_table_read':False,'model_uploaded':False,'gpu_used':False,'runner_cpu_count':os.cpu_count(),'runs':runs,'cp256_rows':len(xx),'cp256_seconds':cp_seconds,'cp256_rows_per_second':len(xx)/cp_seconds,'model_inference_tested':False,'Maya_decoder_ported':False}
    print(json.dumps(result,indent=2),flush=True)
    if os.environ.get('GITHUB_STEP_SUMMARY'):
        Path(os.environ['GITHUB_STEP_SUMMARY']).write_text('Read-only Engram CPU pilot; no model upload or inference.\n\n```json\n'+json.dumps(result,indent=2)+'\n```\n')
if __name__=='__main__':main()

