# Begrenzter Engram-CPU-Pilot für ein öffentliches GitHub-Repository

Vorbereitet, noch nicht auf GitHub ausgeführt. Dieses Paket baut keine veröffentlichungsfähige Modelldatei und lädt nichts nach HF hoch. Dateien dieses Verzeichnisses müssten im Root eines freigegebenen öffentlichen Workflow-Repos liegen; `.github/workflows/engram-pilot.yml` ist manuell startbar.

Der Standard-Runner `ubuntu-24.04` liest standardmäßig etwa 20,6 MB echter Q6_K-Tabellenzeilen, misst Q2_K/Q3_K und sechs CP-256-Zeilen. Er verwendet keine HF-Secrets, keine kostenpflichtigen Runner, keine Modellartefakte und kein Modell-Caching. Größere Arrays sind begrenzt. Der Python-Einstieg verweigert Modelldatenzugriffe außerhalb von GitHub Actions und nichtöffentlichen Repos.

Enthalten: gepinntes Tabelleninventar, der bereits vorhandene experimentelle CP-256-Encoder und sein eingefrorenes Codebook. llama.cpp für die normalen CPU-Quantizer ist auf `c7fc5094179bf8a9c73c18593db714f8da41a402` gepinnt. SHA256SUMS prüft die kleinen Quellen vor dem Lauf. Der Quantizer wird mit CPU-Einstellungen als Bibliothek gebaut.

Dieser neue Linux-Buildpfad ist noch nicht auf dem Runner getestet. Lokal wurden echte kleine Zeilenproben mit der vorhandenen Windows-ggml-Bibliothek erfolgreich verarbeitet. Der vollständige CP-256-Lauf und ein neuer Maya-Decoder gehören nicht zu diesem Pilotpaket. Die Ergebnisse erscheinen nur im kleinen Job-Log und der Job-Zusammenfassung.
