"""Experimental 256-value CPU-only CP-style row codec, L=16, V=2, K=2.

Algorithm references: Han et al., arXiv:2610.21810v2 and Tseng et al.,
QTIP, arXiv:2406.11235 (bitshift/HYB/two-pass tail-biting).
This is a new implementation/format with its own frozen Gaussian codebook,
not an official author checkpoint or a drop-in stock GGUF quant type.
"""
import hashlib,json,math,struct,time
from pathlib import Path
import numpy as np

L=16; STATES=1<<L; DIM=256; STEPS=DIM//2; RECORD_BYTES=66
IQ4=np.array([-127,-104,-83,-65,-49,-35,-22,-10,1,13,25,38,53,69,89,113],dtype=np.float32)

def build_codebook(seed=261021810,samples=32768,iterations=16):
    rng=np.random.default_rng(seed)
    x=rng.normal(size=(samples,2)).astype(np.float32)
    centers=x[rng.choice(samples,512,replace=False)].copy()
    for _ in range(iterations):
        sums=np.zeros((512,2),np.float64); counts=np.zeros(512,np.int64)
        for start in range(0,samples,1024):
            block=x[start:start+1024]
            distances=(block[:,None,0]-centers[None,:,0])**2+(block[:,None,1]-centers[None,:,1])**2
            labels=distances.argmin(axis=1)
            counts+=np.bincount(labels,minlength=512)
            for d in range(2): sums[:,d]+=np.bincount(labels,weights=block[:,d],minlength=512)
        ok=counts>0; centers[ok]=(sums[ok]/counts[ok,None]).astype(np.float32)
    centers*=np.float32(0.95/np.std(centers,dtype=np.float64))
    return centers.astype('<f4')

def expanded_lut(codebook):
    state=np.arange(STATES,dtype=np.uint64)
    mixed=state*(state+1)
    ids=((mixed>>6)&511).astype(np.int32)
    lut=codebook[ids].copy()
    lut[:,0]*=np.where((mixed>>15)&1,-1,1).astype(np.float32)
    return lut.astype(np.float32)

def normalized(x):
    norms=np.linalg.norm(x.astype(np.float64),axis=1)
    y=np.zeros_like(x,dtype=np.float32)
    np.divide(x*np.float32(math.sqrt(DIM)),norms[:,None],out=y,where=norms[:,None]!=0)
    return y,norms

def viterbi_cpu(x,lut,overlap=None):
    batch=len(x); pairs=x.reshape(batch,STEPS,2)
    cost=((pairs[:,0,None,:]-lut[None,:,:])**2).sum(axis=2)
    if overlap is not None:
        valid=(np.arange(STATES)[None,:]>>4)==overlap[:,None]
        cost=np.where(valid,cost,np.float32(np.inf))
    choices=np.zeros((STEPS,batch,4096),np.uint8)
    for t in range(1,STEPS):
        prev=cost.reshape(batch,16,4096)
        picks=prev.argmin(axis=1).astype(np.uint8)
        best=np.take_along_axis(prev,picks[:,None,:].astype(np.int64),axis=1)[:,0,:]
        err=((pairs[:,t,None,:]-lut[None,:,:])**2).sum(axis=2)
        cost=err+np.repeat(best,16,axis=1)
        choices[t]=picks
    if overlap is not None:
        cost=np.where((np.arange(STATES)[None,:]&4095)==overlap[:,None],cost,np.float32(np.inf))
    states=np.empty((batch,STEPS),np.uint16)
    states[:,-1]=cost.argmin(axis=1)
    for t in range(STEPS-1,0,-1):
        group=states[:,t].astype(np.int32)>>4
        states[:,t-1]=group+(choices[t,np.arange(batch),group].astype(np.uint16)<<12)
    return states

def states_from_records(records):
    r=np.asarray(records,dtype=np.uint8).reshape(-1,RECORD_BYTES)
    nibbles=np.empty((len(r),STEPS),np.uint16)
    nibbles[:,0::2]=r[:,:64]&15; nibbles[:,1::2]=r[:,:64]>>4
    return (np.roll(nibbles,3,axis=1)<<12)|(np.roll(nibbles,2,axis=1)<<8)|(np.roll(nibbles,1,axis=1)<<4)|nibbles

def bf16_bits(x):
    u=np.asarray(x,dtype='<f4').view('<u4')
    return ((u+np.uint32(0x7fff)+((u>>16)&1))>>16).astype('<u2')

def bf16_float(bits): return (np.asarray(bits,dtype='<u2').astype('<u4')<<16).view('<f4')

def pack_records(states,x,lut):
    if not np.all((states[:,-1]&4095)==(states[:,0]>>4)): raise ValueError('tail-biting closure failed')
    if not np.all((states[:,1:]>>4)==(states[:,:-1]&4095)): raise ValueError('invalid trellis transitions')
    out=np.zeros((len(states),RECORD_BYTES),np.uint8)
    nib=(states&15).astype(np.uint8)
    out[:,:64]=nib[:,0::2]|(nib[:,1::2]<<4)
    decoded=lut[states].reshape(-1,DIM)
    original_norm=np.linalg.norm(x.astype(np.float64),axis=1)
    coded_norm=np.linalg.norm(decoded.astype(np.float64),axis=1)
    scales=np.divide(original_norm,coded_norm,out=np.zeros_like(original_norm),where=coded_norm!=0).astype('<f4')
    out[:,64:]=bf16_bits(scales).view(np.uint8).reshape(-1,2)
    if not np.array_equal(states,states_from_records(out)): raise ValueError('packed record state round trip failed')
    return out

def decode_records(records,codebook):
    records=np.asarray(records,dtype=np.uint8).reshape(-1,RECORD_BYTES)
    lut=expanded_lut(codebook)
    states=states_from_records(records)
    scales=bf16_float(records[:,64:].copy().reshape(-1).view('<u2'))
    return lut[states].reshape(-1,DIM)*scales[:,None]

def encode_cpu(x,codebook):
    y,_=normalized(x); lut=expanded_lut(codebook)
    warm=viterbi_cpu(np.roll(y,128,axis=1),lut)
    overlap=warm[:,64].astype(np.int32)>>4
    states=viterbi_cpu(y,lut,overlap)
    return pack_records(states,x,lut)

