"""Independent direct-index decoder vs ggml block decoder, no network."""
import ctypes,hashlib,json
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
oracle=ctypes.CDLL(str(ROOT/'build/bin/libggml-base.so'))
candidate=ctypes.CDLL(str(HERE/'libq3k_scalar.so'))
oracle.dequantize_row_q3_K.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_int64]
candidate.sakura_q3_decode.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_size_t]

def check(raw):
    src=ctypes.create_string_buffer(raw);rows=len(raw)//110
    a=np.empty((rows,256),np.float32);b=np.empty_like(a)
    oracle.dequantize_row_q3_K(src,a.ctypes.data,a.size)
    candidate.sakura_q3_decode(src,b.ctypes.data,rows)
    # Signed zeros as well as all finite nonzero values must be bit exact.
    if a.tobytes()!=b.tobytes():
        bad=np.flatnonzero(a.view(np.uint32).reshape(-1)!=b.view(np.uint32).reshape(-1))
        raise AssertionError(f'{len(bad)} mismatches; first {bad[:8]}')
    return rows

real=[]
for p in sorted(HERE.glob('q3-sh*.bin')):
    real.append({'file':p.name,'rows':check(p.read_bytes()),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
if len(real)!=6:raise AssertionError('Expected all six real sample outputs')
rng=np.random.default_rng(20261022)
raw=rng.integers(0,256,size=(4096,110),dtype=np.uint8)
# All random quant codes/scales, finite normal FP16 block multipliers of either sign.
bits=rng.integers(0,65536,size=4096,dtype=np.uint16)
bits=(bits&np.uint16(0x83ff))|np.uint16(0x3c00)
raw[:,108:]=bits.astype('<u2').view(np.uint8).reshape(-1,2)
synthetic_rows=check(raw.tobytes())
# Test all finite FP16 block scales on one representative code pattern, including subnormals and zeros.
scales=np.arange(65536,dtype=np.uint16)
scales=scales[(scales&0x7c00)!=0x7c00]
scale_raw=np.tile(raw[0],(len(scales),1))
scale_raw[:,108:]=scales.astype('<u2').view(np.uint8).reshape(-1,2)
scale_rows=check(scale_raw.tobytes())
result={'reference_revision':'c7fc5094179bf8a9c73c18593db714f8da41a402',
    'real_quantized_sample_rows':sum(x['rows'] for x in real),'real_samples':real,
    'random_code_rows':synthetic_rows,'all_finite_fp16_scale_rows':scale_rows,
    'bit_exact':True,'gpu_compiled':False,'Maya_inference_tested':False}
(HERE/'decoder-parity.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
