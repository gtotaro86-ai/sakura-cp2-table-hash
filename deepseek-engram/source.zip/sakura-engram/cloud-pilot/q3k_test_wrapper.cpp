#include "q3k_value.hpp"
#include <cstddef>
extern "C" void sakura_q3_decode(const uint8_t* src, float* dst, size_t rows) {
    for (size_t r=0;r<rows;++r)
        for (int i=0;i<256;++i)
            dst[r*256+i]=strata::ds4::q3k_value(src+r*110,i);
}
