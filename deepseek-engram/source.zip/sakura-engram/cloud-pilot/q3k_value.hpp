// Scalar Q3_K lookup for one 110-byte/256-value ggml block.
// Layout/reference: llama.cpp c7fc5094179bf8a9c73c18593db714f8da41a402,
// ggml/src/ggml-quants.c dequantize_row_q3_K. No type relabelling.
// This host-testable function is the first step of the Maya Engram port.
#pragma once
#include <cstdint>
#include <cstring>

#if defined(__CUDACC__) || defined(__HIPCC__)
#include <cuda_fp16.h>
#define SAKURA_Q3_INLINE __device__ __forceinline__
#else
#define SAKURA_Q3_INLINE inline
#endif

namespace strata::ds4 {
constexpr int kQ3kBytes = 110;
SAKURA_Q3_INLINE float q3k_value(const uint8_t* b, int i) {
    // i is in [0,256), enforced by the caller's block loop.
    const int group = i >> 4;
    const int packed = b[96 + (group & 7)];
    const int low = group < 8 ? packed & 15 : packed >> 4;
    const int high = (b[104 + (group & 3)] >> (2 * (group >> 2))) & 3;
    const int scale = (low | (high << 4)) - 32;
    const int qlow = (b[32 + (i >> 7) * 32 + (i & 31)] >> (2 * ((i & 127) >> 5))) & 3;
    const int q = qlow - ((b[i & 31] & (1 << (i >> 5))) ? 0 : 4);
    const uint16_t bits = uint16_t(b[108]) | (uint16_t(b[109]) << 8);
#if defined(__CUDACC__) || defined(__HIPCC__)
    const float d = __half2float(__ushort_as_half(bits));
    return __fmul_rn(__fmul_rn(d, float(scale)), float(q));
#else
    _Float16 half;
    std::memcpy(&half, &bits, 2);
    const float d = float(half);
    return (d * float(scale)) * float(q);
#endif
}
} // namespace strata::ds4
#undef SAKURA_Q3_INLINE
