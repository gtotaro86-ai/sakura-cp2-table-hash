// Exercise ORIGINAL Maya reader and row cache using tiny real Q3 samples.
// Local synthetic sparse fixture tests 64-bit offsets; no model downloads.
#include "../sources/maya/src/ds4/ds4_engram_io.hpp"
#include "q3k_value.hpp"
#include <array>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <unistd.h>

using namespace strata::ds4;
static void require(bool ok,const char* message) { if(!ok) throw std::runtime_error(message); }
int main(int argc,char** argv) {
    require(argc==2,"pass one 32-row Q3 sample path");
    std::ifstream in(argv[1],std::ios::binary);
    std::array<uint8_t,32*110> sample{};
    in.read(reinterpret_cast<char*>(sample.data()),sample.size());
    require(in.gcount()==sample.size(),"sample length");
    char path[]="/tmp/sakura-reader-XXXXXX";
    const int fd=mkstemp(path);require(fd>=0,"mkstemp");
    struct Cleanup { int fd;const char* path;~Cleanup(){::close(fd);::unlink(path);} } cleanup{fd,path};
    // Final rows in each table have offsets > 2^32 and > 2^35.
    const uint64_t offset=192+uint64_t(384016682-32)*110;
    require(::pwrite(fd,sample.data(),sample.size(),offset)==sample.size(),"sparse pwrite");
    EgReader reader;reader.start({path},2);
    constexpr int hd=256,scale_bytes=8,cols=4,tokens=3;
    constexpr size_t per=cols*(hd+scale_bytes);
    std::array<uint8_t,tokens*per> slots;slots.fill(0xa5);
    EgBatch batch;
    for(int t=0;t<tokens;++t)for(int c=0;c<cols;++c) {
        EgRead r;r.file=0;r.n=110;r.off=offset+uint64_t(t*cols+c)*110;
        r.dst=slots.data()+t*per+c*hd;
        r.scales=slots.data()+t*per+cols*hd+c*scale_bytes;
        batch.reads.push_back(r);
    }
    reader.submit(batch);reader.wait(batch);
    for(size_t k=0;k<batch.reads.size();++k) {
        const auto& r=batch.reads[k];require(batch.ok[k]==1,"reader success");
        require(std::memcmp(r.dst,sample.data()+k*110,110)==0,"correct 64-bit row and payload");
        for(int i=110;i<hd;++i)require(r.dst[i]==0xa5,"no overwrite in padding");
        for(int i=0;i<scale_bytes;++i)require(r.scales[i]==0xa5,"Q3 does not use external scale bytes");
        for(int i=0;i<256;++i)require(q3k_value(r.dst,i)==q3k_value(sample.data()+k*110,i),"token slot decode");
    }
    EgRowCache cache;cache.init(2,hd+scale_bytes);
    const EgRead& r=batch.reads[0];uint8_t* cached=cache.put(8);
    std::memcpy(cached,r.dst,hd);std::memcpy(cached+hd,r.scales,scale_bytes);
    const uint8_t* hit=cache.find(8);require(hit!=nullptr,"cache hit");
    require(std::memcmp(hit,sample.data(),110)==0,"cache retains compressed bytes");
    std::array<uint8_t,hd+scale_bytes> duplicate{};
    std::memcpy(duplicate.data(),hit,hd+scale_bytes);
    for(int i=0;i<256;++i)require(q3k_value(duplicate.data(),i)==q3k_value(sample.data(),i),"cached duplicate decode");
    cache.put(16);cache.find(8);cache.put(24);require(cache.size()==2,"bounded cache eviction");
    EgBatch short_read;EgRead bad;bad.file=0;bad.n=110;bad.off=offset+sample.size()-1;
    std::array<uint8_t,110> dest{};bad.dst=dest.data();short_read.reads.push_back(bad);
    reader.submit(short_read);reader.wait(short_read);require(short_read.ok[0]==0,"short read signals failure");
    reader.stop();
    std::cout<<"PASS original Maya EgReader/EgRowCache: 12 Q3 rows, 3 tokens x 4 columns, 64-bit offset "
        <<offset<<", padded slots, cached copy, eviction, short read. GPU/inference NOT tested.\n";
}
