"""Explicit ChatGPT cloud CPU pilot. Never masquerades as GitHub Actions.

No authentication, uploads, GPU, full model reads or paid resource creation.
Cumulative reserved HTTP model payload budget (including failed requests): 100 MB.
"""
import argparse, ctypes, fcntl, hashlib, json, os, platform, sys, tempfile, time, urllib.request
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
HERE = Path(__file__).resolve().parent
LIMIT = 100_000_000

def sha(data): return hashlib.sha256(data).hexdigest()

def fetch_range(url, start, count, total, journal, *, limit_bytes=LIMIT):
    # Reserve before opening: failed requests also consume budget. No automatic retry.
    if not (0 <= start < start + count <= total) or count <= 0:
        raise ValueError('Invalid range')
    # Cross-process Linux cloud lock; reserve atomically BEFORE any HTTP request.
    journal = Path(journal)
    with journal.with_suffix(journal.suffix + '.lock').open('a') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        ledger = json.loads(journal.read_text()) if journal.exists() else {'reserved_bytes': 0, 'requests': []}
        if ledger['reserved_bytes'] + count > limit_bytes:
            raise RuntimeError('Cumulative model-data byte budget exhausted')
        ledger['reserved_bytes'] += count
        ledger['requests'].append({'start': start, 'count': count, 'total': total})
        descriptor, temporary = tempfile.mkstemp(dir=journal.parent, prefix='budget-')
        try:
            with os.fdopen(descriptor, 'w') as output:
                json.dump(ledger, output, indent=2)
                output.flush()
                os.fsync(output.fileno())
            os.replace(temporary, journal)
        finally:
            Path(temporary).unlink(missing_ok=True)
    end = start + count - 1
    request = urllib.request.Request(url + f'?cloud_pilot={start}-{end}', headers={
        'Range': f'bytes={start}-{end}', 'Accept-Encoding': 'identity'})
    with urllib.request.urlopen(request, timeout=90) as response:
        if response.status != 206:
            raise RuntimeError(f'HTTP {response.status}: body NOT read; exact 206 required')
        if response.headers.get('Content-Range') != f'bytes {start}-{end}/{total}':
            raise RuntimeError('Wrong Content-Range; body NOT read')
        if response.headers.get('Content-Encoding', 'identity') != 'identity':
            raise RuntimeError('Encoded body rejected before read')
        length = response.headers.get('Content-Length')
        if length is not None and int(length) != count:
            raise RuntimeError('Wrong Content-Length; body NOT read')
        raw = response.read(count + 1)
        if len(raw) != count: raise RuntimeError('Range size mismatch')
    return raw

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--confirm-cloud-cpu', action='store_true', required=True)
    ap.add_argument('--rows', type=int, default=16384)
    ap.add_argument('--library', type=Path, default=ROOT/'build/bin/libggml-base.so')
    args = ap.parse_args()
    if os.environ.get('GITHUB_ACTIONS') == 'true':
        raise SystemExit('This is the distinct cloud entry point, not a GitHub runner')
    if not 16 <= args.rows <= 65536: raise SystemExit('rows must be 16..65536')
    audit = json.loads((ROOT/'table-audit.json').read_text())
    lib = ctypes.CDLL(str(args.library.resolve()))
    for name in ['dequantize_row_q6_K','dequantize_row_q3_K','dequantize_row_q2_K']:
        getattr(lib,name).argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int64]
    lib.ggml_quantize_chunk.argtypes = [ctypes.c_int,ctypes.c_void_p,ctypes.c_void_p,
        ctypes.c_int64,ctypes.c_int64,ctypes.c_int64,ctypes.c_void_p]
    lib.ggml_quantize_chunk.restype = ctypes.c_size_t
    result = {'execution_context':'ChatGPT Work cloud Linux CPU; NOT GitHub Actions',
        'source_revision':audit['revision'],'ggml_revision':'c7fc5094179bf8a9c73c18593db714f8da41a402',
        'cpu_count_visible':os.cpu_count(),'platform':platform.platform(),'numpy':np.__version__,
        'library_sha256':sha(args.library.read_bytes()),'range_bytes':0,'runs':[],
        'model_uploaded':False,'gpu_used':False,'model_inference_tested':False,
        'full_table_read':False,'Maya_decoder_ported':False}
    cp_rows=[]
    for tab in audit['tables']:
        sh=tab['shard']; file=next(c['file'] for c in audit['cached_shards'] if c['shard']==sh)
        url=f"https://huggingface.co/{audit['repo']}/resolve/{audit['revision']}/{file['path']}"
        header=fetch_range(url,0,192,file['size'],HERE/'budget.json')
        if sha(header)!=tab['header_sha256']:raise RuntimeError('Header hash mismatch')
        result['range_bytes']+=len(header)
        rows=tab['tensor']['shape'][1]
        for row_start in (0,rows//2,rows-args.rows):
            count=args.rows*210;tick=time.perf_counter()
            raw=fetch_range(url,192+row_start*210,count,file['size'],HERE/'budget.json')
            fetch_seconds=time.perf_counter()-tick;result['range_bytes']+=len(raw)
            # Verify every old 16-row sample that is contained in this new range.
            verified=[]
            for old in audit['samples']:
                offset=(old['row_start']-row_start)*210
                if old['shard']==sh and 0<=offset<=len(raw)-old['bytes']:
                    if sha(raw[offset:offset+old['bytes']])!=old['sha256']:
                        raise RuntimeError('Handoff sample hash mismatch')
                    verified.append(old['sha256'])
            src=ctypes.create_string_buffer(raw);x=np.empty((args.rows,256),np.float32)
            tick=time.perf_counter();lib.dequantize_row_q6_K(src,x.ctypes.data,x.size)
            dequant_seconds=time.perf_counter()-tick
            if not np.isfinite(x).all():raise RuntimeError('Nonfinite source')
            cp_rows.append(x[0].copy());measurements=[]
            for typ,name,bpr,decoder in [(10,'Q2_K',84,'dequantize_row_q2_K'),(11,'Q3_K',110,'dequantize_row_q3_K')]:
                out=np.empty((args.rows,bpr),np.uint8);times=[];digests=[]
                for _ in range(3):
                    tick=time.perf_counter()
                    size=lib.ggml_quantize_chunk(typ,x.ctypes.data,out.ctypes.data,0,len(x),256,None)
                    times.append(time.perf_counter()-tick)
                    if size!=out.size:raise RuntimeError('Encoded size mismatch')
                    digests.append(sha(out.tobytes()))
                if len(set(digests))!=1:raise RuntimeError('Nondeterministic quantizer')
                recon=np.empty_like(x);getattr(lib,decoder)(out.ctypes.data,recon.ctypes.data,x.size)
                rrmse=float(np.linalg.norm((x-recon).astype(np.float64))/np.linalg.norm(x.astype(np.float64)))
                # Only 32 output rows per sample retained for independent decoder parity.
                if typ==11:(HERE/f'q3-sh{sh}-row{row_start}.bin').write_bytes(out[:32].tobytes())
                measurements.append({'type':name,'seconds':times,'rows_per_second_best':len(x)/min(times),
                    'rows_per_second_median':len(x)/float(np.median(times)), 'sha256':digests[0],
                    'RRMSE_vs_Q6_input_not_model_quality':rrmse})
            item={'shard':sh,'row_start':row_start,'rows':args.rows,'bytes':count,
                'fetch_seconds':fetch_seconds,'q6_dequant_seconds':dequant_seconds,
                'source_sha256':sha(raw),'handoff_samples_verified':verified,'quantizers':measurements}
            result['runs'].append(item)
            (HERE/'results.partial.json').write_text(json.dumps(result,indent=2))
            print(f"shard {sh} row {row_start}: {count} bytes; Q3 {measurements[1]['rows_per_second_median']:.0f} rows/s",flush=True)
    sys.path.insert(0,str(ROOT/'github-pilot'));import cp256_codec
    book=np.load(ROOT/'github-pilot/codebook-v1.npy',allow_pickle=False)
    xx=np.array(cp_rows,dtype=np.float32);tick=time.perf_counter()
    codes=cp256_codec.encode_cpu(xx,book);seconds=time.perf_counter()-tick
    recon=cp256_codec.decode_records(codes,book)
    if not np.isfinite(recon).all():raise RuntimeError('CP decode nonfinite')
    result['cp256']={'rows':len(xx),'seconds':seconds,'rows_per_second':len(xx)/seconds,
        'output_sha256':sha(codes.tobytes()),
        'RRMSE_vs_Q6_input_not_model_quality':float(np.linalg.norm(xx-recon)/np.linalg.norm(xx))}
    (HERE/'results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2),flush=True)

if __name__=='__main__':main()
