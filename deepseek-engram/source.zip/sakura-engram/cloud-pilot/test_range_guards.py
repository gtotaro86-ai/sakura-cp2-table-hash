"""Verify rejection BEFORE body read. No real network calls."""
import json,tempfile,unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from unittest.mock import patch
import run_cloud_pilot as pilot

class Response:
    def __init__(self,status=206,headers=None,raw=b'abcd'):
        self.status=status;self.headers=headers or {};self.raw=raw;self.read_called=False
    def __enter__(self):return self
    def __exit__(self,*args):pass
    def read(self,n):self.read_called=True;return self.raw[:n]

class Guards(unittest.TestCase):
    def run_response(self,response,should_pass=False):
        with tempfile.TemporaryDirectory() as tmp:
            journal=Path(tmp)/'budget.json'
            with patch.object(pilot.urllib.request,'urlopen',return_value=response):
                if should_pass:self.assertEqual(pilot.fetch_range('https://example.invalid/file',2,4,10,journal),b'abcd')
                else:
                    with self.assertRaises(RuntimeError):pilot.fetch_range('https://example.invalid/file',2,4,10,journal)
                    self.assertFalse(response.read_called)
            self.assertEqual(json.loads(journal.read_text())['reserved_bytes'],4)
    def test_whole_200_no_read(self):self.run_response(Response(200,{'Content-Length':'80000000000'}))
    def test_wrong_range_no_read(self):self.run_response(Response(headers={'Content-Range':'bytes 0-3/10'}))
    def test_wrong_length_no_read(self):self.run_response(Response(headers={'Content-Range':'bytes 2-5/10','Content-Length':'10'}))
    def test_compressed_no_read(self):self.run_response(Response(headers={'Content-Range':'bytes 2-5/10','Content-Encoding':'gzip'}))
    def test_exact_range(self):self.run_response(Response(headers={'Content-Range':'bytes 2-5/10','Content-Length':'4'}),True)
    def test_budget_prevents_open(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'budget.json';p.write_text(json.dumps({'reserved_bytes':pilot.LIMIT-3,'requests':[]}))
            with patch.object(pilot.urllib.request,'urlopen') as opener:
                with self.assertRaises(RuntimeError):pilot.fetch_range('https://example.invalid/file',2,4,10,p)
                opener.assert_not_called()
    def test_short_body_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            r=Response(headers={'Content-Range':'bytes 2-5/10'},raw=b'abc')
            with patch.object(pilot.urllib.request,'urlopen',return_value=r):
                with self.assertRaises(RuntimeError):pilot.fetch_range('https://example.invalid/file',2,4,10,Path(tmp)/'b.json')
    def test_parallel_budget_reservations(self):
        with tempfile.TemporaryDirectory() as tmp:
            journal=Path(tmp)/'budget.json'
            journal.write_text(json.dumps({'reserved_bytes':pilot.LIMIT-12,'requests':[]}))
            def attempt(_):
                try:
                    pilot.fetch_range('https://example.invalid/file',2,4,10,journal)
                    return True
                except RuntimeError:return False
            response=Response(headers={'Content-Range':'bytes 2-5/10','Content-Length':'4'})
            with patch.object(pilot.urllib.request,'urlopen',return_value=response):
                with ThreadPoolExecutor(max_workers=4) as pool:outcomes=list(pool.map(attempt,range(4)))
            self.assertEqual(sum(outcomes),3)
            self.assertEqual(json.loads(journal.read_text())['reserved_bytes'],pilot.LIMIT)

if __name__=='__main__':unittest.main()
