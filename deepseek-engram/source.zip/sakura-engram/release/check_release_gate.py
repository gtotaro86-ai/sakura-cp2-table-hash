"""Nonzero exit until real release evidence is available. No network or upload."""
from make_release_plan import plan
import json
if __name__=='__main__':
    result=plan()
    print(json.dumps({'model_release_ready':False,'blocking':result['remaining_gates']},indent=2))
    raise SystemExit(2)
