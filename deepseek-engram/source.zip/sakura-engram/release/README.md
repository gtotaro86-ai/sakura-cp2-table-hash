# Sakura DeepSeek Engram – Cloud-Release

Die Veröffentlichung ohne vollständigen Inferenztest wurde vom Nutzer freigegeben. Die öffentliche Modellkarte enthält den kurzen Hinweis: **„Es wurde kein vollständiger Inferenztest durchgeführt.“**

Aktueller Einstieg und Zugriffseinrichtung: **CLOUD_START.md**. `publish_cloud.py` implementiert Init, blockweisen Q3-Bau/Upload und Finalisierung mit serverseitigem Backbone-Copy. `cloud-release.yml` bereitet dafür kostenlose öffentliche Standard-Runner vor. Es wurde noch kein vollständiger Tabellen-Upload durchgeführt.

Die HF-2.2.0-Kompatibilität des begrenzten Binäradapters und Multipart-Codes ist offline mit simuliertem Transport geprüft. Das ist kein realer Upload-Nachweis. `test_publish_cloud.py` prüft ausschließlich mit Fake-API; keine tatsächliche Veröffentlichung daraus ableiten.

Die frühere Forderung nach einem vollständigen Inferenz-/Qualitätstest als Release-Voraussetzung ist durch die neuere Nutzerentscheidung aufgehoben. Unverändert erforderlich bleiben korrekte Dateistruktur, vollständige Hashes, kostenloser Transport und Speicher sowie der kurze Inferenz-Hinweis. GPU-Ausführung/HIP/Windows sind ungeprüft; CUDA-Übersetzungseinheiten und verlinkter GPU-Test wurden wie in cuda-build-status.json dokumentiert gebaut.

## Reproduktion

Linux, Python 3.12, NumPy 2.3.5, huggingface-hub 2.2.0 und eine CPU-ggml-Bibliothek aus ggml-reference.json. Keine GPU oder vollständigen Modelle für die Offline-Suite nötig.

```bash
python release/run_cpu_checks.py
python release/check_release_gate.py
```

Das Gate bleibt derzeit bei Exitcode 2, weil die eigentlichen vollständigen Dateien noch nicht erzeugt und verifiziert sind. Der Cloud-Finalisierer prüft die remote Dateien, bevor er die vollständige Modellkarte schreibt. Originalübergabe und einzelne historische Messungen bleiben unverändert erhalten.

GPU-Abnahme für eine spätere Laufzeitqualifikation: gepinnten Maya-Checkout patchen, `maya-ds4` und `sakura_engram_q3_test` bauen; der GPU-Test ruft die echten Funktionen `engram_dequant` und `engram_dequant_tok` gegen die mitgelieferten ggml-Float-Fixtures auf. Hier fand keine Ausführung auf GPU statt. `compile_cuda_checks.py` reproduziert lediglich CUDA-Übersetzung und Testlink.
