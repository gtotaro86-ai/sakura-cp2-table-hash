"""Authorized full Q3 table build/publish entry point for FREE public Actions.

NEVER run full model reads in this Work session. No local credential lookup.
Only a public standard runner plus explicitly supplied HF_TOKEN is accepted.
"""
import argparse,hashlib,json,os,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'cloud-pilot'))
from run_cloud_pilot import fetch_range
from virtual_q3 import VirtualQ3,HFBufferedQ3,Quantizer,q3_header

ROOT=Path(__file__).resolve().parents[1]
REPO='peasantsmith/DeepSeek-V4.1-Flash-1017-Maya-GGUF'
REV='b9e25f34b53806b24e5b18085de6ed5967ad9ed5'
MARKER='.sakura-build.json'
NOTICE='Es wurde kein vollständiger Inferenztest durchgeführt.'

def assert_public_metadata(payload):
    text=payload.decode('utf-8').lower() if isinstance(payload,bytes) else str(payload).lower()
    if 'gtotaro86' in text or 'sakura-cp2-table-hash' in text:
        raise RuntimeError('Personal GitHub/hash repository reference forbidden in public HF metadata')

def require_runner(env):
    if env.get('GITHUB_ACTIONS')!='true' or env.get('REPO_VISIBILITY')!='public' or env.get('RUNNER_ENVIRONMENT')!='github-hosted':
        raise RuntimeError('Full build allowed only on a real public GitHub-hosted runner; refusing Work/local execution')
    if env.get('SAKURA_FREE_STANDARD_RUNNER')!='ubuntu-24.04':raise RuntimeError('Standard free runner required')
    if env.get('SAKURA_STORAGE_CONFIRMED') not in ('true','auto-free-account'):raise RuntimeError('No-cost HF destination storage must be confirmed')
    if not env.get('HF_TOKEN'):raise RuntimeError('HF_TOKEN must be supplied securely as a GitHub secret')

def audit_and_identity():
    audit=json.loads((ROOT/'table-audit.json').read_text())
    if audit['repo']!=REPO or audit['revision']!=REV:raise RuntimeError('Only pinned source allowed')
    return audit,{'source_repo':REPO,'source_revision':REV,'format':'Q3_K',
        'patch_sha256':hashlib.sha256((ROOT/'cloud-pilot/maya-q3k-draft.patch').read_bytes()).hexdigest(),
        'inference_test_performed':False,'release_notice':NOTICE}

def target_allowed(repo):
    if repo==REPO or len(repo.split('/'))!=2 or not repo.split('/')[1].startswith('Sakura-DeepSeek-V4.1-Flash-1017'):
        raise ValueError('Use a dedicated Sakura-DeepSeek-V4.1-Flash-1017... destination, never an existing Flash-Next repo')

def get_json(api,repo,path):
    # Small authenticated metadata only; explicit token and no local auth fallback.
    import httpx2
    url=f'https://huggingface.co/{repo}/resolve/main/{path}'
    with httpx2.Client(follow_redirects=False,timeout=60) as client:
        response=client.get(url,headers={'Authorization':'Bearer '+os.environ['HF_TOKEN']})
        # resolve may redirect metadata to a same-origin cache URL; use HF hf_hub_url cache bypass below.
        if response.status_code in (301,302,303,307,308):
            from urllib.parse import urljoin,urlsplit
            location=urljoin(url,response.headers['location'])
            if urlsplit(location).netloc!='huggingface.co':raise RuntimeError('Unexpected small-metadata redirect')
            response=client.get(location,headers={'Authorization':'Bearer '+os.environ['HF_TOKEN']})
        response.raise_for_status()
        if len(response.content)>1024*1024:raise RuntimeError('Metadata response too large')
        return response.json()

def check_destination(api,repo,identity):
    info=api.model_info(repo)
    if info.private:raise RuntimeError('Destination must be public; no private storage charges')
    if get_json(api,repo,MARKER)!=identity:raise RuntimeError('Destination marker differs; refusing to overwrite')

def initialize(api,repo,identity):
    from huggingface_hub import CommitOperationAdd
    from huggingface_hub.utils import RepositoryNotFoundError
    initialize_empty = False
    try:
        existing = api.model_info(repo)
        if existing.private:raise RuntimeError('Destination must be public')
        names = {item.rfilename for item in (existing.siblings or [])}
        if MARKER not in names:
            if names - {'.gitattributes'}:
                raise RuntimeError('Existing destination is not empty; refusing overwrite')
            initialize_empty = True
    except RepositoryNotFoundError:
        api.create_repo(repo_id=repo,repo_type='model',private=False,exist_ok=False)
        initialize_empty = True
    if initialize_empty:
        api.create_commit(repo_id=repo,operations=[
            CommitOperationAdd(path_in_repo=MARKER,path_or_fileobj=(json.dumps(identity,indent=2)+'\n').encode()),
            CommitOperationAdd(path_in_repo='README.md',path_or_fileobj=b'# Sakura DeepSeek Engram Q3_K\n\nBuild in progress. Incomplete; do not download yet.\n')],
            commit_message='Initialize authorized cloud build; incomplete until finalization')
    check_destination(api,repo,identity)

class FullTableSource:
    def __init__(self,audit,shard,journal):
        require_runner(os.environ)
        self.table=next(t for t in audit['tables'] if t['shard']==shard)
        self.file=next(t['file'] for t in audit['cached_shards'] if t['shard']==shard)
        expected=f'Maya-S/DeepSeek-V4.1-Flash-1017-Maya-S-IQ2_XXS-{shard:05}-of-00006.gguf'
        if shard not in (5,6) or self.file['path']!=expected:raise RuntimeError('Wrong table shard')
        self.url=f'https://huggingface.co/{REPO}/resolve/{REV}/{expected}'
        self.journal=journal
        # Hash pass + upload pass + one bounded retry pass. Never an unlimited source reader.
        self.limit=3*self.table['tensor']['span']+192
    def __call__(self,off,count):
        if off<0 or off%210 or count<=0 or count%210 or count>1048576*210 or off+count>self.table['tensor']['span']:
            raise ValueError('Invalid/alignment/out-of-bounds Q6 table range')
        return fetch_range(self.url,192+off,count,self.file['size'],self.journal,limit_bytes=self.limit)

def verify_remote_file(api,repo,path,size,sha):
    items=list(api.get_paths_info(repo_id=repo,paths=[path],repo_type='model',expand=True))
    if len(items)!=1 or items[0].size!=size or items[0].lfs is None or items[0].lfs.sha256!=sha:
        raise RuntimeError('Remote size/LFS hash mismatch: '+path)

def build_shard(api,repo,audit,identity,shard,block_rows):
    from huggingface_hub import CommitOperationAdd
    check_destination(api,repo,identity)
    src=FullTableSource(audit,shard,ROOT/f'full-shard{shard}-budget.json')
    table=src.table;header=(ROOT/f'release/shard{shard}-header.bin').read_bytes()
    header=q3_header(header,table)
    # Preserve all source names and split metadata; first four shards stay byte-identical.
    raw=VirtualQ3(header,table['tensor']['shape'][1],src,Quantizer(ROOT/'build/bin/libggml-base.so'),
                  block_rows=block_rows,cache_blocks=1)
    tick=time.perf_counter()
    with HFBufferedQ3(raw) as stream:
        operation=CommitOperationAdd(path_in_repo=src.file['path'],path_or_fileobj=stream)
        digest=operation.upload_info.sha256.hex();size=operation.upload_info.size
        api.create_commit(repo_id=repo,operations=[operation],commit_message=f'Add Q3_K Engram table shard {shard}')
        verify_remote_file(api,repo,src.file['path'],size,digest)
    result={'shard':shard,'path':src.file['path'],'size':size,'sha256':digest,
        'elapsed_seconds':time.perf_counter()-tick,'source_budget':json.loads(src.journal.read_text()),
        'inference_test_performed':False,'identity':identity}
    assert_public_metadata(json.dumps(result))
    api.create_commit(repo_id=repo,operations=[CommitOperationAdd(path_in_repo=f'build/shard{shard}.json',
        path_or_fileobj=(json.dumps(result,indent=2)+'\n').encode())],commit_message=f'Verify shard {shard} size and SHA256')
    print(json.dumps({'shard':shard,'size':size,'sha256':digest,'elapsed_seconds':result['elapsed_seconds']},indent=2))

def finalize(api,repo,audit,identity):
    from huggingface_hub import CommitOperationAdd,CommitOperationCopy
    check_destination(api,repo,identity)
    tables=[]
    for shard in (5,6):
        record=get_json(api,repo,f'build/shard{shard}.json')
        if record['identity']!=identity or record['shard']!=shard:raise RuntimeError('Wrong build evidence')
        expected_rows=next(t['tensor']['shape'][1] for t in audit['tables'] if t['shard']==shard)
        if record['size']!=192+expected_rows*110:raise RuntimeError('Wrong Q3 file size')
        verify_remote_file(api,repo,record['path'],record['size'],record['sha256']);tables.append(record)
    # Copy only the four original LFS backbone files. Same-region/quota failures must stop publication.
    copies=[CommitOperationCopy(src_repo_id=REPO,src_repo_type='model',src_revision=REV,
        src_path_in_repo=x['file']['path'],path_in_repo=x['file']['path'])
        for x in audit['cached_shards'] if x['shard']<5]
    api.create_commit(repo_id=repo,operations=copies,commit_message='Copy four unchanged backbone shards server-side')
    body=[x['file'] for x in audit['cached_shards'] if x['shard']<5]
    for file in body:verify_remote_file(api,repo,file['path'],file['size'],file['sha256'])
    manifest={'identity':identity,'complete':True,'backbone':body,'tables':tables,
        'model_inference_tested':False,'gpu_runtime_executed':False}
    readme=(ROOT/'release/MODEL_CARD_DRAFT.md').read_text()
    readme=readme.replace('Dateiprüfsummen und Buildstand werden nach abgeschlossenem Cloud-Bau in build-manifest.json eingetragen.',
                          'Dateiprüfsummen und Buildstand: build-manifest.json. Runtime-Patch: runtime/maya-q3k.patch.')
    operations=[CommitOperationAdd(path_in_repo='build-manifest.json',path_or_fileobj=(json.dumps(manifest,indent=2)+'\n').encode()),
        CommitOperationAdd(path_in_repo='README.md',path_or_fileobj=readme.encode()),
        CommitOperationAdd(path_in_repo='runtime/maya-q3k.patch',path_or_fileobj=str(ROOT/'cloud-pilot/maya-q3k-draft.patch'))]
    for name,source in [('LICENSE.llama.cpp',ROOT/'sources/llama-LICENSE'),('LICENSE.Maya',ROOT/'sources/maya/LICENSE'),
                        ('LICENSE.DeepSeek',ROOT/'sources/maya/LICENSE.deepseek-v41')]:
        operations.append(CommitOperationAdd(path_in_repo=name,path_or_fileobj=str(source)))
    # Public metadata/code is self-contained on HF; never link the user's personal build repo.
    for operation in operations:
        payload=operation.path_or_fileobj
        assert_public_metadata(Path(payload).read_bytes() if isinstance(payload,str) else payload)
    api.create_commit(repo_id=repo,operations=operations,commit_message='Release complete Sakura Engram Q3_K; no full inference test')
    print('Release complete: https://huggingface.co/'+repo)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('phase',choices=['init','shard','finalize'])
    ap.add_argument('--repo',required=True);ap.add_argument('--shard',type=int,choices=[5,6])
    ap.add_argument('--block-rows',type=int,default=1048576);args=ap.parse_args()
    require_runner(os.environ);target_allowed(args.repo)
    import huggingface_hub
    if huggingface_hub.__version__!='2.2.0':raise RuntimeError('Pinned huggingface-hub 2.2.0 required')
    from huggingface_hub import HfApi
    api=HfApi(token=os.environ['HF_TOKEN']);audit,identity=audit_and_identity()
    if os.environ.get('SAKURA_STORAGE_CONFIRMED')=='auto-free-account':
        account=api.whoami()
        if account.get('isPro') is not False or args.repo.split('/')[0]!=account.get('name'):
            raise RuntimeError('Automatic no-cost mode requires the authenticated personal FREE HF account; no paid storage assumed')
    if args.phase=='init':initialize(api,args.repo,identity)
    elif args.phase=='shard':
        if args.shard is None:raise RuntimeError('--shard required')
        build_shard(api,args.repo,audit,identity,args.shard,args.block_rows)
    else:finalize(api,args.repo,audit,identity)
if __name__=='__main__':main()
