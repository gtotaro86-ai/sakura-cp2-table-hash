"""Run offline CPU release checks. Requires existing pinned llama source/build."""
import json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
os.chdir(ROOT)
LOG=ROOT/'release/cpu-checks.log'
env=os.environ.copy();env['ASAN_OPTIONS']='detect_leaks=0'
commands=[
 ['g++','-std=c++17','-O2','-ffp-contract=off','-shared','-fPIC','cloud-pilot/q3k_test_wrapper.cpp','-o','cloud-pilot/libq3k_scalar.so'],
 [sys.executable,'cloud-pilot/test_q3_parity.py'],
 [sys.executable,'cloud-pilot/test_range_guards.py'],
 ['g++','-std=c++17','-O2','-pthread','-ffp-contract=off','-fsanitize=address,undefined','cloud-pilot/test_maya_reader.cpp','-o','/tmp/sakura-maya-reader-test'],
 ['/tmp/sakura-maya-reader-test','cloud-pilot/q3-sh6-row0.bin'],
 ['g++','-std=c++17','-O2','-fsanitize=address,undefined','release/test_engram_format.cpp','-o','/tmp/sakura-format-test'],
 ['/tmp/sakura-format-test'],
 [sys.executable,'release/test_virtual_q3.py'],
 [sys.executable,'release/test_bounded_source.py'],
 [sys.executable,'release/test_hf_stream.py'],
 [sys.executable,'release/test_publish_cloud.py'],
 [sys.executable,'release/test_overview_privacy.py'],
 [sys.executable,'release/make_release_plan.py'],
]
results=[]
with LOG.open('w') as log:
    for cmd in commands:
        tick=time.perf_counter();log.write('COMMAND '+repr(cmd)+'\n');log.flush()
        result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env)
        results.append({'command':cmd,'returncode':result.returncode,'seconds':time.perf_counter()-tick})
        if result.returncode:
            print('FAILED; see',LOG);break
output={'passed':len(results)==len(commands) and all(x['returncode']==0 for x in results),
    'network_model_bytes':0,'gpu_compilation_in_this_cpu_suite':False,'model_inference_tested':False,
    'leak_sanitizer_disabled_reason':'Cloud /proc/ptrace limitation; ASan/UBSan active on C++ reader/geometry checks',
    'results':results}
(ROOT/'release/cpu-checks.json').write_text(json.dumps(output,indent=2)+'\n')
print('CPU checks PASS' if output['passed'] else 'CPU checks FAIL')
raise SystemExit(0 if output['passed'] else 1)
