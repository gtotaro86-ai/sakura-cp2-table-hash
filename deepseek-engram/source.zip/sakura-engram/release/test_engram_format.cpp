#include "../maya-q3-draft/src/ds4/ds4_engram_format.hpp"
#include <cassert>
#include <iostream>
using namespace strata::ds4;
int main() {
    assert(engram_qk_layout_valid(kEngramQ3K,256,384006168,42240678480ULL));
    assert(engram_qk_layout_valid(kEngramQ6K,256,384006168,80641295280ULL));
    assert(!engram_qk_layout_valid(kEngramQ3K,256,384006168,80641295280ULL));
    assert(!engram_qk_layout_valid(kEngramQ3K,255,4,440));
    assert(!engram_qk_layout_valid(kEngramQ3K,0,4,440));
    assert(!engram_qk_layout_valid(99,256,4,440));
    assert(!engram_qk_layout_valid(kEngramQ3K,256,0,0));
    assert(!engram_qk_layout_valid(kEngramQ3K,256,UINT64_MAX,110));
    assert(engram_range_valid(192,42240678480ULL,42240678672ULL));
    assert(!engram_range_valid(193,42240678480ULL,42240678672ULL));
    assert(!engram_range_valid(UINT64_MAX,1,UINT64_MAX));
    std::cout<<"PASS Engram format geometry: Q3/Q6 sizes, invalid layouts, overflow, file bounds\n";
}
