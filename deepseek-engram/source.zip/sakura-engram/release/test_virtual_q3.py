import ctypes,hashlib,importlib.util,io,json,random,struct,tempfile,unittest
from pathlib import Path
import virtual_q3 as v

HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
AUDIT=json.loads((ROOT/'table-audit.json').read_text())

class StreamTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.quant=v.Quantizer(ROOT/'build/bin/libggml-base.so')
        cls.raw=(HERE/'shard5-q6-first32.bin').read_bytes()
        cls.full_header=v.q3_header((HERE/'shard5-header.bin').read_bytes(),AUDIT['tables'][0])
        # Small file fixture declares EXACTLY 32 rows; never label a truncated table as complete.
        header=bytearray(cls.full_header)
        _,_,_,_,typepos=v.tensor_descriptor(header)
        struct.pack_into('<Q',header,typepos-8,32)
        cls.header=bytes(header)
        cls.expected=cls.header+cls.quant(cls.raw)
    def stream(self,block=7,cache=1):
        return v.VirtualQ3(self.header,32,lambda off,n:self.raw[off:off+n],self.quant,block,cache)
    def test_read_seek_boundaries(self):
        rng=random.Random(261022)
        with self.stream() as s:
            for _ in range(300):
                pos=rng.randrange(len(self.expected)+100);count=rng.randrange(700)
                s.seek(pos);self.assertEqual(s.read(count),self.expected[pos:pos+count])
            s.seek(-100,io.SEEK_END);buf=bytearray(120);self.assertEqual(s.readinto(buf),100)
            self.assertEqual(bytes(buf[:100]),self.expected[-100:])
            self.assertEqual(s.read(1),b'')
            with self.assertRaises(ValueError):s.seek(-1)
            with self.assertRaises(ValueError):s.read(s.max_read+1)
        with self.assertRaises(ValueError):s.read(1)
    def test_chunk_independent_and_two_hash_passes(self):
        expected=hashlib.sha256(self.expected).hexdigest()
        for block in [1,3,7,16,32,64]:
            with self.stream(block) as s:
                self.assertEqual(v.hash_stream(s,127),expected)
                s.cache.clear()
                self.assertEqual(v.hash_stream(s,113),expected)
                self.assertLessEqual(len(s.cache),1)
    def test_short_source_atomic_position(self):
        with v.VirtualQ3(self.header,32,lambda o,n:b'',self.quant,1) as s:
            s.seek(191)
            with self.assertRaises(OSError):s.read(10)
            self.assertEqual(s.tell(),191)
    def test_huge_seek_does_not_fetch(self):
        def forbidden(*a):raise AssertionError('Seek must not read')
        with v.VirtualQ3(self.full_header,384006168,forbidden,self.quant) as s:
            self.assertEqual(s.seek(0,io.SEEK_END),42240678672)
            self.assertEqual(s.read(1),b'')
            with self.assertRaises(ValueError):s.seek(0);s.read()
    def test_exact_changed_header_bytes_and_maya_packer(self):
        spec=importlib.util.spec_from_file_location('maya_pack',ROOT/'sources/maya/tools/ds4/pack_gguf.py')
        maya=importlib.util.module_from_spec(spec);spec.loader.exec_module(maya)
        for table in AUDIT['tables']:
            header=(HERE/f'shard{table["shard"]}-header.bin').read_bytes()
            changed=v.q3_header(header,table)
            self.assertEqual(sum(a!=b for a,b in zip(header,changed)),1)
            with tempfile.TemporaryDirectory() as temp:
                file=Path(temp)/'header.gguf';file.write_bytes(changed)
                parsed=maya.Gguf(file)
                self.assertEqual(parsed.data_start,192)
                self.assertEqual(parsed.tensors,[(table['tensor']['name'],11,table['tensor']['shape'],0)])
                self.assertEqual(maya.TYPES[11],('Q3_K',256,110))
                self.assertEqual(parsed.kv,maya.Gguf(self._write(Path(temp)/'old.gguf',header)).kv)
            corrupt=bytearray(header);corrupt[0]^=1
            with self.assertRaises(ValueError):v.q3_header(corrupt,table)
    @staticmethod
    def _write(path,data):path.write_bytes(data);return path
    def test_decode_final_stream(self):
        # Independent candidate decoder of exact payload emitted through odd read sizes.
        import numpy as np
        lib=ctypes.CDLL(str(ROOT/'cloud-pilot/libq3k_scalar.so'))
        lib.sakura_q3_decode.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_size_t]
        with self.stream(3) as s:output=s.read()
        buf=ctypes.create_string_buffer(output[192:]);a=np.empty((32,256),np.float32);b=np.empty_like(a)
        lib.sakura_q3_decode(buf,a.ctypes.data,32)
        self.quant.lib.dequantize_row_q3_K.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_int64]
        self.quant.lib.dequantize_row_q3_K(buf,b.ctypes.data,b.size)
        self.assertEqual(a.tobytes(),b.tobytes())
    def test_header_row_mismatch_rejected(self):
        with self.assertRaises(ValueError):v.VirtualQ3(self.full_header,32,None,None)
    def test_invalid_configuration(self):
        for rows,block,cache,maxread in [(0,1,1,110),(1,0,1,110),(1,1,5,110),(1,1,1,10)]:
            with self.assertRaises(ValueError):v.VirtualQ3(self.header,rows,None,None,block,cache,maxread)

if __name__=='__main__':unittest.main()
