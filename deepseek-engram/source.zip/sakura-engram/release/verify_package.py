"""Check final checkpoint paths and SHA256; offline, no mutations."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if __name__=='__main__':
    entries=json.loads((ROOT/'CHECKPOINT-SHA256.json').read_text())
    for name,expected in entries.items():
        path=ROOT/name
        if not path.resolve().is_relative_to(ROOT.resolve()):raise SystemExit('Unsafe manifest path')
        if hashlib.sha256(path.read_bytes()).hexdigest()!=expected:raise SystemExit('Hash mismatch: '+name)
    print('PASS checkpoint SHA256:',len(entries),'files')
