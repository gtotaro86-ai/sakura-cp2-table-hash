# Noch auszuführende Modellabnahme

Dieser Plan wurde vorbereitet, nicht ausgeführt. Zeilen-RRMSE und CPU-/GPU-Decoder-Parität ersetzen ihn nicht.

1. **Vergleichspaar:** dieselben vier Maya-S-Backbone-Shards und identische Tokenizer-/Hash-Metadaten; einmal originale Q6_K-Tabellen, einmal vollständig erzeugte Q3_K-Tabellen. Exakte Datei-/Patch-/Binary-Hashes erfassen. Keine anderen Quant-/Runtime-Optimierungen gleichzeitig ändern.
2. **Decoderabnahme zuerst:** sechs mitgelieferte Proben durch beide echten GPU-Pfade prüfen; vorhandene Q6-/FP8-Tests müssen weiter bestehen. Prefill mit mehreren Tokens, Decode, Chunk-Grenzen, Cache an/aus, wiederholte N-Grams, beide Engram-Layer und neue/duplizierte Zeilen prüfen. Keine außerhalb der Tensor-/Dateigrenzen liegenden Reads akzeptieren.
3. **Inferenz-Smoketest:** echte Prompts mit langen und wiederholten Tokenfolgen, Unicode, Code und Gesprächswechseln; auf NaNs, Fehler, Loops und Truncation prüfen. Identische Seeds und Samplingparameter verwenden und speichern.
4. **Qualität:** einen vorher festgelegten und unveränderten Coding-Aufgabensatz mit objektiven Tests und eine unveränderte Textmenge zur Loss-/PPL-Messung verwenden. Ergebnisse beider Varianten, Anzahl Aufgaben/Tokens, Kontexte, Prompt-/Testdatenhashes und Wiederholungen erfassen. Keine Aufgaben nach Ergebnis selektieren. Annahmegrenzen müssen vor dem großen Vergleich festgelegt werden; bisher wurde keine akzeptable Qualitätsverschlechterung vom Nutzer freigegeben.
5. **Zielhardware:** Ryzen AI Max+ 392, Radeon 8060S/gfx1151, 64 GB UMA; verwendete Speicheraufteilung, freier RAM, Betriebssystem, ROCm/HIP-/Treiberstand und Ablage auf SSD dokumentieren. Laufzeit auf CUDA-Hardware beweist keine AMD-/Windows-Kompatibilität.
6. **Praktischer Betrieb:** Prompt-Processing und Decode getrennt, Kalt-/Warmstart und Cacheeffekte, RAM-/UMA-/Diskverbrauch messen. Vollständige Dateigröße nicht als Arbeitsspeicherbedarf angeben. Engram-Hashing/Tabellenadressierung bleibt unverändert.

Es wurden weder ein externer Inferenzdienst noch bezahlte APIs/GPUs benutzt oder dafür Aufträge erstellt. Keine gegenwärtige Cloud-Ausführung behaupten, wenn der jeweilige Job beendet ist.
