import json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import bounded_source as b
ROOT=Path(__file__).resolve().parents[1]
class SourceTests(unittest.TestCase):
    def setUp(self):self.audit=json.loads((ROOT/'table-audit.json').read_text())
    def test_public_pinned_and_range_translation(self):
        with tempfile.TemporaryDirectory() as d:
            with patch.object(b,'fetch_range',return_value=b'x'*210) as fetch:
                source=b.BoundedHFSource(self.audit,5,Path(d)/'ledger.json')
                fetch.assert_not_called();self.assertEqual(source(210,210),b'x'*210)
                args=fetch.call_args.args
                self.assertIn(b.REVISION,args[0]);self.assertEqual(args[1:4],(402,210,80641295472))
    def test_reject_nonpinned_source(self):
        self.audit['revision']='main'
        with self.assertRaises(ValueError):b.BoundedHFSource(self.audit,5,'never-created')
    def test_reject_unaligned_and_unbounded_without_network(self):
        source=b.BoundedHFSource(self.audit,6,'never-created')
        with patch.object(b,'fetch_range') as fetch:
            for off,n in [(-210,210),(1,210),(0,211),(0,65537*210),(80643503220,210)]:
                with self.assertRaises(ValueError):source(off,n)
            fetch.assert_not_called()
if __name__=='__main__':unittest.main()
