"""Read-only HF secret/identity check on Actions. Never print token/response body."""
import json,os
from pathlib import Path

def main():
    token=os.environ.get('HF_TOKEN')
    result={'hf_token_configured':bool(token),'hf_authenticated':False,'model_upload_started':False}
    if token:
        try:
            from huggingface_hub import HfApi
            info=HfApi(token=token).whoami()
            result.update(hf_authenticated=True,hf_user=info.get('name'),is_pro=info.get('isPro'),
                token_role=info.get('auth',{}).get('accessToken',{}).get('role'))
        except Exception as error:
            result['error_type']=type(error).__name__
    Path('release/access-preflight.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    if os.environ.get('GITHUB_STEP_SUMMARY'):
        with open(os.environ['GITHUB_STEP_SUMMARY'],'a') as f:
            f.write('## HF access preflight (read only)\n\n```json\n'+json.dumps(result,indent=2)+'\n```\n')
if __name__=='__main__':main()
