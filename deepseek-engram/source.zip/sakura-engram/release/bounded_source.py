"""Public pinned HF source for VirtualQ3. Defaults to the existing 100 MB ledger.
No upload functionality or credentials. Constructing does no HTTP requests.
"""
import sys,threading
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'cloud-pilot'))
from run_cloud_pilot import fetch_range

REPO='peasantsmith/DeepSeek-V4.1-Flash-1017-Maya-GGUF'
REVISION='b9e25f34b53806b24e5b18085de6ed5967ad9ed5'

class BoundedHFSource:
    def __init__(self,audit,shard,journal):
        if audit['repo']!=REPO or audit['revision']!=REVISION or shard not in (5,6):
            raise ValueError('Only the pinned public Engram source is allowed')
        self.table=next(t for t in audit['tables'] if t['shard']==shard)
        self.file=next(s['file'] for s in audit['cached_shards'] if s['shard']==shard)
        expected=f'Maya-S/DeepSeek-V4.1-Flash-1017-Maya-S-IQ2_XXS-{shard:05}-of-00006.gguf'
        if self.file['path']!=expected or self.file['size']!=192+self.table['tensor']['span']:
            raise ValueError('Unexpected shard layout')
        self.url=f'https://huggingface.co/{REPO}/resolve/{REVISION}/{expected}'
        self.journal=Path(journal);self.lock=threading.Lock()
    def __call__(self,offset,count):
        if offset<0 or count<=0 or offset%210 or count%210 or count>65536*210:
            raise ValueError('Aligned bounded Q6 ranges required')
        if offset+count>self.table['tensor']['span']:raise ValueError('Past table end')
        # Single-process threaded calls serialize ledger reservation and HTTP I/O.
        # fetch_range also locks ledger reservation across Linux processes.
        with self.lock:
            return fetch_range(self.url,192+offset,count,self.file['size'],self.journal)
