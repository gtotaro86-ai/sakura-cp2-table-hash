"""Offline publish control-flow checks. Fake API only; no repo/write/network."""
import contextlib,io,json,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import publish_cloud as p
ROOT=Path(__file__).resolve().parents[1]

class PublishTests(unittest.TestCase):
    def test_private_github_never_in_public_hf_metadata(self):
        p.assert_public_metadata('Source: peasantsmith/DeepSeek-V4.1-Flash-1017-Maya-GGUF')
        for text in ['https://github.com/gtotaro86-ai/sakura-cp2-table-hash','sakura-cp2-table-hash']:
            with self.assertRaises(RuntimeError):p.assert_public_metadata(text)
    def test_work_local_full_reads_refused(self):
        with self.assertRaises(RuntimeError):p.require_runner({})
        with self.assertRaises(RuntimeError):p.FullTableSource({},5,Path('never-created'))
    def test_destination_restrictions(self):
        p.target_allowed('example/Sakura-DeepSeek-V4.1-Flash-1017-Engram-Q3_K-GGUF')
        for repo in [p.REPO,'gtotaro86-ai/sakura-cp2-table-hash','webmp3/Sakura-Qwen3.8-Flash-Next-Compact-GGUF','x/y/z']:
            with self.assertRaises(ValueError):p.target_allowed(repo)
    def test_verified_finalization_only(self):
        audit,identity=p.audit_and_identity();records={};files={}
        for sh in (5,6):
            file=next(x['file'] for x in audit['cached_shards'] if x['shard']==sh)
            rows=next(t['tensor']['shape'][1] for t in audit['tables'] if t['shard']==sh)
            record={'identity':identity,'shard':sh,'path':file['path'],'size':192+rows*110,'sha256':str(sh)*64}
            records[f'build/shard{sh}.json']=record;files[file['path']]=record
        for x in audit['cached_shards']:
            if x['shard']<5:files[x['file']['path']]=x['file']
        calls=[]
        class FakeAPI:
            def model_info(self,repo):return SimpleNamespace(private=False)
            def get_paths_info(self,repo_id,paths,**kwargs):
                f=files[paths[0]];return [SimpleNamespace(size=f['size'],lfs=SimpleNamespace(sha256=f['sha256']))]
            def create_commit(self,**kwargs):calls.append(kwargs)
        def fixture_json(api,repo,path):return identity if path==p.MARKER else records[path]
        with patch.object(p,'get_json',side_effect=fixture_json),contextlib.redirect_stdout(io.StringIO()):
            p.finalize(FakeAPI(),'example/Sakura-DeepSeek-V4.1-Flash-1017-Test',audit,identity)
        self.assertEqual(len(calls),2)
        self.assertEqual(len(calls[0]['operations']),4)
        for op in calls[0]['operations']:
            self.assertEqual(op.src_revision,p.REV);self.assertEqual(op.src_repo_id,p.REPO)
        readme=next(x for x in calls[1]['operations'] if x.path_in_repo=='README.md').path_or_fileobj.decode()
        self.assertIn(p.NOTICE,readme);self.assertNotIn('experiment',readme.lower())
        calls.clear();records['build/shard6.json']['size']-=1
        with patch.object(p,'get_json',side_effect=fixture_json):
            with self.assertRaises(RuntimeError):p.finalize(FakeAPI(),'example/Sakura-DeepSeek-V4.1-Flash-1017-Test',audit,identity)
        self.assertEqual(calls,[])
    def test_remote_sha_must_match(self):
        api=SimpleNamespace(get_paths_info=lambda **kw:[SimpleNamespace(size=3,lfs=SimpleNamespace(sha256='a'*64))])
        with self.assertRaises(RuntimeError):p.verify_remote_file(api,'example/repo','file',3,'b'*64)
    def test_initialize_only_empty_or_matching_destination(self):
        _,identity=p.audit_and_identity();calls=[]
        info=SimpleNamespace(private=False,siblings=[SimpleNamespace(rfilename='.gitattributes')])
        api=SimpleNamespace(model_info=lambda repo:info,create_commit=lambda **kw:calls.append(kw))
        with patch.object(p,'get_json',return_value=identity):p.initialize(api,'example/new',identity)
        self.assertEqual(len(calls),1)
        calls.clear();info.siblings.append(SimpleNamespace(rfilename='existing-model.gguf'))
        with self.assertRaises(RuntimeError):p.initialize(api,'example/new',identity)
        self.assertEqual(calls,[])

if __name__=='__main__':unittest.main()
