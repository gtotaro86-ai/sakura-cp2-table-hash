"""Read-only seekable Q6_K -> Q3_K table GGUF. No uploads or implicit networking.

A source callable must return EXACT requested Q6 payload bytes. Production
network sources must impose their own persistent budget before each request.
Only the audited one-tensor, 192-byte-header shards are accepted here.
"""
import ctypes
import hashlib
import io
import struct
from collections import OrderedDict
from pathlib import Path
import numpy as np

def tensor_descriptor(header):
    if len(header)!=192 or header[:4]!=b'GGUF' or struct.unpack_from('<I',header,4)[0]!=3:
        raise ValueError('Audited GGUF v3 header layout required')
    if struct.unpack_from('<Q',header,8)[0]!=1:raise ValueError('One table tensor required')
    pos=106;length=struct.unpack_from('<Q',header,pos)[0];pos+=8
    if length>64 or pos+length+32>192:raise ValueError('Invalid tensor name length')
    name=header[pos:pos+length].decode();pos+=length
    if name not in ('blk.1.engram_embd.weight','blk.14.engram_embd.weight'):
        raise ValueError('Only the two audited Engram tensors are supported')
    ndims=struct.unpack_from('<I',header,pos)[0];pos+=4
    if ndims!=2:raise ValueError('Two tensor dimensions required')
    shape=struct.unpack_from('<QQ',header,pos);pos+=16
    typ=struct.unpack_from('<I',header,pos)[0];offset=struct.unpack_from('<Q',header,pos+4)[0]
    return name,shape,typ,offset,pos

def q3_header(header, table):
    if len(header)!=192 or hashlib.sha256(header).hexdigest()!=table['header_sha256']:
        raise ValueError('Unrecognised pinned GGUF header')
    if header[:4]!=b'GGUF' or struct.unpack_from('<I',header,4)[0]!=3:
        raise ValueError('GGUF v3 required')
    if struct.unpack_from('<Q',header,8)[0]!=1:
        raise ValueError('Exactly one tensor required')
    tensor=table['tensor'];pos=tensor['entry_start']
    length=struct.unpack_from('<Q',header,pos)[0];pos+=8
    name=header[pos:pos+length].decode();pos+=length
    ndims=struct.unpack_from('<I',header,pos)[0];pos+=4
    shape=struct.unpack_from('<'+'Q'*ndims,header,pos);pos+=8*ndims
    typ=struct.unpack_from('<I',header,pos)[0]
    offset=struct.unpack_from('<Q',header,pos+4)[0]
    if name!=tensor['name'] or list(shape)!=tensor['shape'] or typ!=14 or offset!=0:
        raise ValueError('Wrong name, dimensions, dtype or tensor offset')
    if pos+12!=tensor['entry_end'] or tensor['absolute']!=192 or shape[0]!=256:
        raise ValueError('Unexpected tensor directory layout')
    output=bytearray(header);struct.pack_into('<I',output,pos,11)
    return bytes(output)

class Quantizer:
    def __init__(self,library):
        self.lib=ctypes.CDLL(str(Path(library).resolve()))
        self.lib.dequantize_row_q6_K.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_int64]
        self.lib.ggml_quantize_chunk.argtypes=[ctypes.c_int,ctypes.c_void_p,ctypes.c_void_p,
            ctypes.c_int64,ctypes.c_int64,ctypes.c_int64,ctypes.c_void_p]
        self.lib.ggml_quantize_chunk.restype=ctypes.c_size_t
    def __call__(self,raw):
        if not raw or len(raw)%210:raise ValueError('Whole Q6_K rows required')
        rows=len(raw)//210;src=ctypes.create_string_buffer(raw)
        values=np.empty((rows,256),np.float32)
        self.lib.dequantize_row_q6_K(src,values.ctypes.data,values.size)
        if not np.isfinite(values).all():raise ValueError('Nonfinite source')
        output=np.empty((rows,110),np.uint8)
        count=self.lib.ggml_quantize_chunk(11,values.ctypes.data,output.ctypes.data,0,rows,256,None)
        if count!=output.size:raise RuntimeError('Quantizer output size mismatch')
        return output.tobytes()

class VirtualQ3(io.RawIOBase):
    """Single-reader stream; bounded blocks/cache and bounded read(-1).

    Size includes unchanged header metadata and newly typed Q3 payload. Seeking
    does no I/O. Hash-then-upload readers can rewind deterministically. All
    production bytes still require a complete encoding pass, never free copy.
    """
    def __init__(self,header,rows,source,quantizer,block_rows=16384,cache_blocks=2,max_read=8*1024*1024):
        super().__init__()
        if len(header)!=192 or not isinstance(rows,int) or rows<=0:
            raise ValueError('192-byte header and positive row count required')
        _,shape,typ,offset,_=tensor_descriptor(header)
        if shape!=(256,rows) or typ!=11 or offset!=0:
            raise ValueError('Stream length must match the Q3 tensor header exactly')
        if not 1<=block_rows<=1048576 or not 1<=cache_blocks<=4 or not 110<=max_read<=64*1024*1024:
            raise ValueError('Unbounded buffering forbidden')
        self.header=header;self.rows=rows;self.source=source;self.quantizer=quantizer
        self.block_rows=block_rows;self.cache_blocks=cache_blocks;self.max_read=max_read
        self.cache=OrderedDict();self.pos=0;self.size=192+rows*110
    def readable(self):return not self.closed
    def seekable(self):return not self.closed
    def tell(self):self._checkClosed();return self.pos
    def seek(self,offset,whence=io.SEEK_SET):
        self._checkClosed()
        if not isinstance(offset,int):raise TypeError('Integer offset required')
        if whence not in (io.SEEK_SET,io.SEEK_CUR,io.SEEK_END):raise ValueError('Invalid whence')
        pos=offset+(0 if whence==io.SEEK_SET else self.pos if whence==io.SEEK_CUR else self.size)
        if pos<0:raise ValueError('Negative seek')
        self.pos=pos;return pos
    def _block(self,index):
        if index in self.cache:
            self.cache.move_to_end(index);return self.cache[index]
        first=index*self.block_rows;rows=min(self.block_rows,self.rows-first)
        raw=self.source(first*210,rows*210)
        if len(raw)!=rows*210:raise OSError('Source short read')
        output=self.quantizer(raw)
        if len(output)!=rows*110:raise OSError('Wrong Q3 block size')
        self.cache[index]=output
        while len(self.cache)>self.cache_blocks:self.cache.popitem(last=False)
        return output
    def read(self,size=-1):
        self._checkClosed()
        if size is None or size<0:size=max(0,self.size-self.pos)
        if size>self.max_read:raise ValueError('Read exceeds bounded RAM request; use chunks/readinto')
        remaining=min(size,max(0,self.size-self.pos));chunks=[];pos=self.pos
        while remaining:
            if pos<192:
                part=self.header[pos:min(192,pos+remaining)]
            else:
                payload=pos-192;span=self.block_rows*110
                block=self._block(payload//span);offset=payload%span
                part=block[offset:offset+remaining]
            if not part:raise OSError('Unexpected empty block')
            chunks.append(part);pos+=len(part);remaining-=len(part)
        self.pos=pos;return b''.join(chunks)
    def readinto(self,buffer):
        view=memoryview(buffer).cast('B');raw=self.read(len(view));view[:len(raw)]=raw;return len(raw)
    def close(self):
        self.cache.clear();super().close()

def hash_stream(stream,chunk=1024*1024):
    """Explicit full pass over the stream passed by the caller. No networking here."""
    if not 1<=chunk<=stream.max_read:raise ValueError('Invalid hash chunk')
    stream.seek(0);digest=hashlib.sha256()
    while True:
        raw=stream.read(chunk)
        if not raw:break
        digest.update(raw)
    return digest.hexdigest()

class HFBufferedQ3(io.BufferedIOBase):
    """HF-compatible binary file facade without read-all buffering.

    Hugging Face requires BufferedIOBase. Ordinary BufferedReader.read() may
    accumulate an entire huge stream; this adapter retains VirtualQ3's limit.
    """
    def __init__(self,raw):super().__init__();self.raw=raw
    def readable(self):return not self.closed
    def seekable(self):return not self.closed
    def tell(self):self._checkClosed();return self.raw.tell()
    def seek(self,offset,whence=io.SEEK_SET):self._checkClosed();return self.raw.seek(offset,whence)
    def read(self,size=-1):self._checkClosed();return self.raw.read(size)
    def readinto(self,buffer):self._checkClosed();return self.raw.readinto(buffer)
    def __iter__(self):
        while True:
            block=self.read(4*1024*1024)
            if not block:break
            yield block
    def close(self):
        if not self.closed:self.raw.close()
        super().close()
