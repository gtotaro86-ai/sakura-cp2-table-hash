"""Offline plan only. Does not read table payloads, copy weights or publish."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def plan():
    audit=json.loads((ROOT/'table-audit.json').read_text())
    patch=ROOT/'cloud-pilot/maya-q3k-draft.patch'
    body=[x['file'] for x in audit['cached_shards'] if x['shard']<5]
    tables=[]
    for t in audit['tables']:
        rows=t['tensor']['shape'][1]
        tables.append({'shard':t['shard'],'tensor':t['tensor']['name'],'rows':rows,'type':11,
            'format':'Q3_K','payload_bytes':rows*110,'gguf_file_bytes':192+rows*110,
            'source_header_sha256':t['header_sha256'],'output_sha256':None})
    cuda=json.loads((ROOT/'release/cuda-build-status.json').read_text()) if (ROOT/'release/cuda-build-status.json').exists() else {}
    cpu=json.loads((ROOT/'release/cpu-checks.json').read_text()) if (ROOT/'release/cpu-checks.json').exists() else {}
    return {'status':'PRE_RELEASE_BLOCKED','model_release_ready':False,
        'source_repo':audit['repo'],'source_revision':audit['revision'],
        'maya_revision':'451f9cb6a21ea65673bdde2e57b4a670ae2b8859',
        'ggml_revision':'c7fc5094179bf8a9c73c18593db714f8da41a402',
        'patch_sha256':hashlib.sha256(patch.read_bytes()).hexdigest(),
        'unchanged_backbone':body,'q3_tables':tables,
        'candidate_total_main_file_bytes':sum(f['size'] for f in body)+sum(t['gguf_file_bytes'] for t in tables),
        'destination_repo':None,'publication_authorized':True,'upload_implemented':True,
        'evidence':{'cpu_suite_passed':cpu.get('passed',False),
            'cuda_translation_units_compiled':cuda.get('cuda_translation_units_compiled',False),
            'gpu_test_linked':cuda.get('gpu_test_linked',False),'gpu_executed':False,
            'hip_compiled':False,'windows_build':False,'full_maya_executable_linked':False},
        'unperformed_validation':['Full model inference and quality comparison',
            'Actual GPU execution and HIP/Windows qualification'],
        'remaining_gates':['GitHub workflow publication and real cloud run',
            'HF write access and no-cost public storage',
            'Complete streaming build, upload and six remote file hashes',
            'Successful same-region backbone copy and final manifest'],
        'notes':'Payload RRMSE is NOT model quality. Virtual streaming tests are NOT a full-table run.'}

if __name__=='__main__':
    result=plan();path=ROOT/'release/release-plan.json';path.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
