"""Remove only the requested personal GitHub references from HF README files."""
import json,os,re
from pathlib import Path
REPO='webmp3/Sakura-Qwen3.8-Flash-Next-Overview'
FORBIDDEN=re.compile(r'gtotaro86|sakura-cp2-table-hash',re.I)

def clean_text(text):
    lines=[]
    for line in text.splitlines(keepends=True):
        if not FORBIDDEN.search(line):lines.append(line);continue
        if line.startswith('Build/hash scripts:'):
            line=re.sub(r'^Build/hash scripts:.*?\. Three public publishing runs',
                'Build/hash scripts were inspected. Three publishing runs',line)
        def unlink(match):
            label,url=match.group(1),match.group(2)
            if FORBIDDEN.search(url):return 'build records' if FORBIDDEN.search(label) else label
            return match.group(0)
        line=re.sub(r'\[([^\]]*)\]\(([^)]*)\)',unlink,line)
        if FORBIDDEN.search(line):raise RuntimeError('Unexpected personal reference; refusing broad text edits')
        lines.append(line)
    return ''.join(lines)

def main():
    result={'repository':REPO,'applied':False,'token_configured':bool(os.environ.get('HF_TOKEN'))}
    if not result['token_configured']:
        print(json.dumps(result));return
    from huggingface_hub import HfApi,hf_hub_download,CommitOperationAdd
    api=HfApi(token=os.environ['HF_TOKEN']);info=api.model_info(REPO)
    if info.private:raise RuntimeError('Expected public overview repository')
    operations=[];changed=[]
    for file in (info.siblings or []):
        if not re.fullmatch(r'README(?:_[A-Za-z-]+)?\.md',file.rfilename):continue
        data=list(api.get_paths_info(repo_id=REPO,paths=[file.rfilename],repo_type='model',revision=info.sha))
        if len(data)!=1 or data[0].size>1024*1024:raise RuntimeError('Unexpected README size')
        path=hf_hub_download(repo_id=REPO,filename=file.rfilename,revision=info.sha,token=os.environ['HF_TOKEN'])
        old=Path(path).read_text();new=clean_text(old)
        if old!=new:
            operations.append(CommitOperationAdd(path_in_repo=file.rfilename,path_or_fileobj=new.encode()))
            changed.append(file.rfilename)
    if operations:
        commit=api.create_commit(repo_id=REPO,operations=operations,parent_commit=info.sha,
            commit_message='Remove personal GitHub references from overview')
        result.update(applied=True,changed_files=changed,commit=commit.oid)
    else:result.update(applied=True,changed_files=[])
    Path('release/overview-privacy-result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    if os.environ.get('GITHUB_STEP_SUMMARY'):
        with open(os.environ['GITHUB_STEP_SUMMARY'],'a') as f:f.write('## Overview privacy correction\n\n```json\n'+json.dumps(result,indent=2)+'\n```\n')
if __name__=='__main__':main()
