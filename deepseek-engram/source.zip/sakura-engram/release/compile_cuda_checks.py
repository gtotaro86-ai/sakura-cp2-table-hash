"""Compile CUDA translation units and LINK the real GPU test, never execute it.

Requires a patched Maya checkout and an existing CUDA SDK. No package install,
cloud allocation, credentials, model reads or GPU execution are performed.
"""
import argparse,hashlib,json,subprocess,time
from pathlib import Path

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--sdk',required=True,type=Path)
    ap.add_argument('--maya',required=True,type=Path);ap.add_argument('--output',required=True,type=Path)
    ap.add_argument('--arch',default='sm_80');args=ap.parse_args()
    sdk=args.sdk.resolve();maya=args.maya.resolve();out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
    nvcc=sdk/'bin/nvcc'
    if not (maya/'src/ds4/ds4_q3k.cuh').exists():raise SystemExit('Patched Maya checkout required')
    flags=[str(nvcc),'-std=c++17','-arch='+args.arch,'-I'+str(sdk/'include/cccl')]
    commands=[flags+['-c',str(maya/'src/ds4/ds4_kernels.cu'),'-o',str(out/'kernels.o')],
        flags+['-c',str(maya/'tests/sakura_engram_q3_test.cu'),'-o',str(out/'gpu-test.o')],
        flags+['-DSTRATA_VERSION="1.1.21-sakura-q3-pre"','-I'+str(maya/'include'),
            '-I'+str(maya/'third_party/ggml'),'-c',str(maya/'src/ds4/ds4_model.cu'),'-o',str(out/'model.o')],
        flags+[str(out/'gpu-test.o'),str(out/'kernels.o'),'-L'+str(sdk/'lib'),'-o',str(out/'sakura-engram-q3-gpu-test')]]
    results=[]
    for n,command in enumerate(commands):
        tick=time.perf_counter();log=out/f'compile-{n}.log'
        with log.open('w') as f:result=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
        results.append({'command':command,'returncode':result.returncode,'seconds':time.perf_counter()-tick,
            'log':log.name})
        if result.returncode:break
    report={'cuda_compiler':subprocess.check_output([str(nvcc),'--version'],text=True),
        'maya_revision':'451f9cb6a21ea65673bdde2e57b4a670ae2b8859 plus Sakura patch',
        'cuda_translation_units_compiled':len(results)==4 and all(x['returncode']==0 for x in results),
        'gpu_test_linked':len(results)==4 and results[-1]['returncode']==0,
        'full_maya_executable_linked':False,'gpu_executed':False,'hip_compiled':False,
        'windows_build':False,'model_inference_tested':False,'results':results,
        'source_sha256':{str(p.relative_to(maya)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in [maya/'src/ds4/ds4_model.cu',maya/'src/ds4/ds4_kernels.cu',
                      maya/'src/ds4/ds4_q3k.cuh',maya/'tests/sakura_engram_q3_test.cu']}}
    (out/'cuda-build-status.json').write_text(json.dumps(report,indent=2)+'\n')
    print('CUDA compile/link PASS; NO GPU execution' if report['gpu_test_linked'] else 'CUDA compile FAIL')
    raise SystemExit(0 if report['gpu_test_linked'] else 1)
if __name__=='__main__':main()
