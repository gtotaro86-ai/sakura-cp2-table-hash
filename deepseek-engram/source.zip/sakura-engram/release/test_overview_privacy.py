import unittest
from sanitize_overview import clean_text
class PrivacyTests(unittest.TestCase):
    def test_unlink_and_preserve_technical_statement(self):
        text='The table matched in a [full streaming SHA256 run](https://github.com/gtotaro86-ai/sakura-cp2-table-hash/actions/runs/123). Equal shapes were not proof.\n'
        new=clean_text(text)
        self.assertEqual(new,'The table matched in a full streaming SHA256 run. Equal shapes were not proof.\n')
    def test_replace_build_reference_prefix(self):
        text='Build/hash scripts: [gtotaro86-ai/sakura-cp2-table-hash](https://github.com/gtotaro86-ai/sakura-cp2-table-hash), inspected commit `abcd`. Three public publishing runs completed successfully. Whole unchanged files were copied inside HF.\n'
        self.assertEqual(clean_text(text),'Build/hash scripts were inspected. Three publishing runs completed successfully. Whole unchanged files were copied inside HF.\n')
    def test_keep_unrelated_content(self):
        text='Runtime: https://github.com/mw00/project-maya\n';self.assertEqual(clean_text(text),text)
    def test_fail_closed_on_unexpected_reference(self):
        with self.assertRaises(RuntimeError):clean_text('Unknown prose about gtotaro86 here')
if __name__=='__main__':unittest.main()
