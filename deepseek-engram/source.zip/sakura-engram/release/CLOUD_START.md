# Cloud-Bau und Veröffentlichung

Der Nutzer hat den vollständigen Cloud-Bau und Release ohne vollständigen Inferenztest freigegeben. Der öffentliche Hinweis lautet ausschließlich: **„Es wurde kein vollständiger Inferenztest durchgeführt.“**

## Ablauf

`cloud-release.yml` verwendet ausschließlich öffentliche Standard-`ubuntu-24.04`-Runner. Zwei Jobs quantisieren je eine Tabelle; es werden keine vollständigen Modelle geladen. Ein seekbarer HF-kompatibler Binäradapter liefert begrenzte Blöcke, HF hasht den Stream und liest ihn für den Upload erneut. Quelldaten werden nur mit exakten gepinnten HTTP-206-Ranges gelesen. Die vier Rumpfdateien werden danach serverseitig kopiert.

Jeder Tabellenjob ist auf 350 Minuten und höchstens drei Quellen-Payload-Durchläufe begrenzt (normalerweise Hash + Upload, zusätzlicher Spielraum für Wiederholungen). Ein Block hat höchstens 1.048.576 Zeilen: ca. 220 MB Q6-Input, 1,074 GB F32-Zwischenarray und 115 MB Q3-Output, dazu Kopien/Cache. Das ist kein Nachweis des tatsächlichen Runner-Peaks; es bleibt deutlich unter einem vollständigen Tabellendownload im RAM. Die 100-MB-Grenze gilt weiterhin für Proben/Piloten in Work. Volltabellenzugriff verweigert das Skript außerhalb echter öffentlicher GitHub-Runner.

## Aktueller Prüfstand

- Der Binäradapter wurde gegen **huggingface-hub 2.2.0** geprüft: echte UploadInfo-Hashbildung, Multipart-/Slice-Code, Zurückspulen und Zusammensetzen ergeben dieselben Bytes; der HTTP-Transport war dabei simuliert.
- Der rohe RawIOBase-Stream wird von HF abgelehnt; der eigene BufferedIOBase-Adapter erfüllt die API und behält den RAM-Lesegrenzwert bei.
- Der Finalisierer prüft beide Q3-Dateigrößen und remote LFS-SHA256, kopiert nur die vier gepinnten Rumpfdateien und prüft danach auch deren LFS-Hashes. Nur dann werden endgültige Modellkarte und Buildmanifest geschrieben.
- Offline-Fake-API-Tests decken falsche Größen/Hashes, verbotene Ziele, lokale Vollbau-Sperre und die kontrollierte Finalisierung ab. Keine Offline-Testausgabe als echten Upload ausgeben.
- Ein wirklicher vollständiger Upload und seine Laufzeit wurden **noch nicht** gemessen. Ein Abbruch lässt eine klar als unvollständig beschriftete öffentliche Build-Ablage zurück; es wird dann keine vollständige Modellfreigabe behauptet.

## GitHub und HF

GitHub ist als `gtotaro86-ai` verbunden. Das vorhandene öffentliche Repository `sakura-cp2-table-hash` ist erreichbar. Die beiden alten Workflows sind ausschließlich manuell startbar; sie werden nicht gestartet oder überschrieben. Der DeepSeek-Quellstand und neue Workflows können getrennt ergänzt werden.

Das bisherige Publish-Workflow referenziert bereits ein GitHub-Secret namens `HF_TOKEN`. Das beweist nicht, dass es aktuell gesetzt oder für das neue HF-Ziel ausreichend berechtigt ist. Der neue read-only Zugriffstest meldet nur Vorhandensein, Anmeldeerfolg, HF-Nutzername und Tokenrolle; niemals den Tokenwert.

Falls nötig:

1. HF-Zielmodell leer und **öffentlich** unter https://huggingface.co/new anlegen, Name mit `Sakura-DeepSeek-V4.1-Flash-1017` beginnend. Keine Modellkarte erforderlich.
2. Unter https://huggingface.co/settings/tokens einen feingranularen Token mit Schreibrecht ausschließlich für dieses Zielrepo erzeugen. Ein vorhandener ausreichend berechtigter Token kann weiterverwendet werden.
3. Auf GitHub: Repository → Settings → Secrets and variables → Actions → New repository secret. Name exakt `HF_TOKEN`, Wert dort geschützt einfügen. **Nicht in Chat, Code oder Logs einfügen.**
4. Ausreichenden kostenlosen öffentlichen HF-Speicher prüfen. Keine private Ablage, kostenpflichtige Erweiterung oder bezahlte Runner beauftragen.
5. Neuen Workflow „Build and release DeepSeek Engram Q3_K“ starten, Zielrepo und bestätigten kostenlosen Speicher angeben.

Der Quellrunner erzeugt keine GitHub-Modellartefakte oder großen Caches. HF-Region/Quota können den serverseitigen Kopiervorgang verhindern; es gibt keinen automatischen kostenpflichtigen oder vollständigen Backbone-Download-Fallback.
