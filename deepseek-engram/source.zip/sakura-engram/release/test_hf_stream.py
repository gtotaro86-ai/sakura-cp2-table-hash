"""HF 2.2.0 real file-object validation/multipart code, simulated transport only."""
import hashlib,io,json,struct,unittest
from pathlib import Path
from unittest.mock import patch
import httpx2 as httpx
import huggingface_hub
from huggingface_hub import CommitOperationAdd,CommitOperationCopy
from huggingface_hub import lfs
from virtual_q3 import VirtualQ3,Quantizer,q3_header,tensor_descriptor,HFBufferedQ3

ROOT=Path(__file__).resolve().parents[1]
class HFStreamTests(unittest.TestCase):
    def setUp(self):
        self.assertEqual(huggingface_hub.__version__,'2.2.0')
        audit=json.loads((ROOT/'table-audit.json').read_text());self.audit=audit
        header=bytearray(q3_header((ROOT/'release/shard5-header.bin').read_bytes(),audit['tables'][0]))
        typepos=tensor_descriptor(header)[4];struct.pack_into('<Q',header,typepos-8,32)
        self.header=bytes(header);self.raw=(ROOT/'release/shard5-q6-first32.bin').read_bytes()
        self.quant=Quantizer(ROOT/'build/bin/libggml-base.so')
        self.expected=self.header+self.quant(self.raw)
    def test_hash_slice_multipart_and_rewind(self):
        stream=VirtualQ3(self.header,32,lambda o,n:self.raw[o:o+n],self.quant,block_rows=7,cache_blocks=1)
        with HFBufferedQ3(stream) as buffered:
            operation=CommitOperationAdd(path_in_repo='tables.gguf',path_or_fileobj=buffered)
            self.assertEqual(operation.upload_info.size,len(self.expected))
            self.assertEqual(operation.upload_info.sha256.hex(),hashlib.sha256(self.expected).hexdigest())
            self.assertEqual(buffered.tell(),0)
            emitted=[]
            def fake_upload(method,url,**kwargs):
                self.assertEqual(method,'PUT');part=b''.join(kwargs['data'])
                emitted.append(part)
                return httpx.Response(200,headers={'etag':f'part-{len(emitted)}'},request=httpx.Request(method,url))
            # Real HF multipart path, awkward 1,001-byte boundaries cross rows/blocks.
            part_size=1001;urls=[f'https://example.invalid/{n}' for n in range((len(self.expected)+part_size-1)//part_size)]
            with patch.object(lfs,'http_backoff',side_effect=fake_upload):
                headers=lfs._upload_parts_iteratively(operation,urls,part_size)
            self.assertEqual(b''.join(emitted),self.expected)
            self.assertEqual(len(headers),len(urls));self.assertEqual(buffered.tell(),0)
            self.assertEqual(buffered.read(),self.expected)
    def test_copy_operation_is_pinned(self):
        source=self.audit['cached_shards'][0]['file']['path']
        operation=CommitOperationCopy(src_repo_id=self.audit['repo'],src_repo_type='model',
            src_revision=self.audit['revision'],src_path_in_repo=source,path_in_repo=source)
        self.assertEqual(operation.src_revision,self.audit['revision'])
    def test_unbuffered_raw_stream_is_rejected(self):
        with VirtualQ3(self.header,32,lambda o,n:self.raw[o:o+n],self.quant) as stream:
            with self.assertRaises(ValueError):CommitOperationAdd(path_in_repo='table.gguf',path_or_fileobj=stream)

if __name__=='__main__':unittest.main()
