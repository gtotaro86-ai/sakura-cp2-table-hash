# Sakura DeepSeek V4.1 Flash 1017 – Engram Q3_K

Die beiden Engram-Tabellen werden von Q6_K auf Q3_K quantisiert. Die vier Modellrumpf-Dateien bleiben unverändert.

Quelle: peasantsmith/DeepSeek-V4.1-Flash-1017-Maya-GGUF, Revision b9e25f34b53806b24e5b18085de6ed5967ad9ed5.

**Es wurde kein vollständiger Inferenztest durchgeführt.**

Benötigt den mitgelieferten Q3_K-Engram-Patch für Maya. Dateiprüfsummen und Buildstand werden nach abgeschlossenem Cloud-Bau in build-manifest.json eingetragen.
